# Contributing

- keep claims honest
- do not submit novelty ciphers
- prefer small, reviewable changes
- add tests for parser, tamper, and failure behavior
- keep secrets out of logs and fixtures
