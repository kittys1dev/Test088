from __future__ import annotations

import argparse
from pathlib import Path
from textwrap import dedent


def write_file(root: Path, rel_path: str, content: str) -> None:
    path = root / rel_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(dedent(content).lstrip("\n"), encoding="utf-8")


FILES: dict[str, str] = {
    "Cargo.toml": r'''
        [workspace]
        resolver = "2"
        members = [
            "crates/aurora-fs-core",
            "crates/aurora-fs-crypto",
            "crates/aurora-fs-kdf",
            "crates/aurora-fs-container",
            "crates/aurora-fs-cli",
            "crates/aurora-fs-testvectors",
            "crates/aurora-fs-fuzz",
        ]

        [workspace.package]
        version = "0.1.0"
        edition = "2021"
        license = "MIT"
        rust-version = "1.76"
        authors = ["AURORA-FS Contributors"]
        repository = "https://github.com/YOUR-USERNAME/aurora-fs"
        description = "AURORA-FS local-first file encryption toolkit"

        [workspace.dependencies]
        aes-gcm-siv = "0.11.1"
        aes-keywrap = "0.9.0"
        argon2 = { version = "0.5.3", default-features = false, features = ["std"] }
        base64 = "0.22"
        clap = { version = "4.5", features = ["derive"] }
        getrandom = "0.4"
        tiny-keccak = { version = "2.0.2", features = ["kmac"] }
        zeroize = "1.8"

        [workspace.lints.rust]
        unsafe_code = "forbid"
    ''',
    "rust-toolchain.toml": r'''
        [toolchain]
        channel = "stable"
        components = ["clippy", "rustfmt"]
    ''',
    ".gitignore": r'''
        target/
        .DS_Store
        *.aur
        *.key
        *.bin
        *.txt
    ''',
    "README.md": r'''
        # AURORA-FS

        AURORA-FS is a local-first, offline-capable, no-backdoor file-encryption project.

        ## Current status

        This is a **pre-alpha** repository scaffold with a narrow working path:

        - `aurora info`
        - `aurora keygen`
        - `aurora keyarmor export`
        - `aurora keyarmor import`
        - `aurora encrypt --key-file ...`
        - `aurora decrypt --key-file ...`

        Current end-to-end support is intentionally narrow:

        - standard mode only
        - key-file unlock only
        - no detached signatures
        - no passphrase or hybrid unlock yet
        - no encrypted metadata block yet
        - no rekey yet

        ## Build

        ```bash
        cargo build --workspace
        cargo test --workspace
        cargo run -p aurora-fs-cli -- keygen -o mykey.bin
        cargo run -p aurora-fs-cli -- encrypt secrets.txt --key-file mykey.bin
        cargo run -p aurora-fs-cli -- decrypt secrets.aur --key-file mykey.bin
        ```

        ## Security note

        Do not market this as a finished security product yet.
        Ship nothing public as production-safe until external review, deterministic vectors, tamper tests, and wrong-key failure behavior are complete.
    ''',
    "LICENSE": r'''
        MIT License

        Copyright (c) 2026 AURORA-FS Contributors

        Permission is hereby granted, free of charge, to any person obtaining a copy
        of this software and associated documentation files (the "Software"), to deal
        in the Software without restriction, including without limitation the rights
        to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
        copies of the Software, and to permit persons to whom the Software is
        furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be included in all
        copies or substantial portions of the Software.

        THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
        IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
        FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
        AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
        LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
        OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
        SOFTWARE.
    ''',
    "SECURITY.md": r'''
        # Security Policy

        AURORA-FS is pre-alpha.
        Unsupported or incomplete cryptographic operations must fail closed.

        Do not open public issues for unreleased crypto-path vulnerabilities.
        Establish a private security contact before public alpha.
    ''',
    "CONTRIBUTING.md": r'''
        # Contributing

        - keep claims honest
        - do not submit novelty ciphers
        - prefer small, reviewable changes
        - add tests for parser, tamper, and failure behavior
        - keep secrets out of logs and fixtures
    ''',
    "clippy.toml": r'''
        msrv = "1.76"
    ''',
    "deny.toml": r'''
        [licenses]
        allow = ["MIT", "Apache-2.0", "BSD-3-Clause", "ISC"]
    ''',
    "dist-workspace.toml": r'''
        [dist]
        cargo-dist-version = "0.30.2"
        ci = ["github"]
        installers = ["shell", "powershell"]
        targets = [
          "x86_64-unknown-linux-gnu",
          "x86_64-pc-windows-msvc",
          "x86_64-apple-darwin",
          "aarch64-apple-darwin",
        ]
        unix-archive = ".tar.gz"
        windows-archive = ".zip"
        install-path = "CARGO_HOME"
        install-updater = false
    ''',
    "docs/cli.md": r'''
        # CLI Notes

        Working commands:
        - info
        - keygen
        - keyarmor export
        - keyarmor import
        - encrypt --key-file
        - decrypt --key-file

        Stubbed fail-closed commands:
        - rekey
        - verify
    ''',
    "docs/format.md": r'''
        # AURORA-FS Container Notes

        Current generated container layout:

        - 58-byte fixed prelude
        - one key slot record
        - no header extensions
        - no encrypted metadata block yet
        - fixed-size chunk table
        - ciphertext stream

        Current implementation supports key-file-only standard mode.
    ''',
    "docs/release.md": r'''
        # Release Notes

        ## GitHub ZIP download

        After pushing this repository to GitHub, GitHub automatically provides a downloadable ZIP from the repository page.

        ## Release artifacts

        Intended release flow:
        - push repository
        - tag a version like `v0.1.0`
        - let GitHub Actions build artifacts
        - optionally use cargo-dist for install scripts and archives

        ## Local release smoke test

        ```bash
        cargo build --workspace
        cargo test --workspace
        cargo install cargo-dist --locked
        cargo dist build
        ```
    ''',
    ".github/workflows/ci.yml": r'''
        name: ci

        on:
          push:
          pull_request:

        jobs:
          test:
            strategy:
              fail-fast: false
              matrix:
                os: [ubuntu-latest, windows-latest, macos-latest]
            runs-on: ${{ matrix.os }}
            steps:
              - uses: actions/checkout@v4
              - name: Install Rust toolchain
                uses: dtolnay/rust-toolchain@stable
                with:
                  components: clippy,rustfmt
              - name: Cache cargo
                uses: Swatinem/rust-cache@v2
              - name: Check formatting
                run: cargo fmt --all --check
              - name: Lint
                run: cargo clippy --workspace --all-targets -- -D warnings
              - name: Test
                run: cargo test --workspace
    ''',
    ".github/workflows/release.yml": r'''
        name: release

        on:
          workflow_dispatch:
          push:
            tags:
              - "v*"

        jobs:
          dist:
            runs-on: ubuntu-latest
            permissions:
              contents: write
            steps:
              - uses: actions/checkout@v4
              - name: Install Rust toolchain
                uses: dtolnay/rust-toolchain@stable
              - name: Install cargo-dist
                run: cargo install cargo-dist --locked
              - name: Build release artifacts
                run: cargo dist build --tag ${{ github.ref_name }} || cargo dist build
    ''',
    ".github/workflows/labels.yml": r'''
        name: labels

        on:
          workflow_dispatch:

        jobs:
          sync-labels:
            runs-on: ubuntu-latest
            permissions:
              issues: write
              contents: read
            steps:
              - uses: actions/checkout@v4
              - uses: crazy-max/ghaction-github-labeler@v5
                with:
                  yaml-file: .github/labels.yml
    ''',
    ".github/labels.yml": r'''
        - name: bug
          color: d73a4a
          description: Something is not working
        - name: enhancement
          color: a2eeef
          description: New feature or request
        - name: documentation
          color: 0075ca
          description: Documentation improvements
        - name: security
          color: b60205
          description: Security-sensitive issue
        - name: crypto
          color: 5319e7
          description: Cryptography and format work
        - name: good first issue
          color: 7057ff
          description: Good for newcomers
        - name: help wanted
          color: 008672
          description: Extra attention is needed
    ''',
    ".github/ISSUE_TEMPLATE/bug_report.yml": r'''
        name: Bug report
        description: Report a bug in AURORA-FS
        title: "[bug]: "
        labels: ["bug"]
        body:
          - type: textarea
            id: summary
            attributes:
              label: Summary
            validations:
              required: true
          - type: textarea
            id: steps
            attributes:
              label: Steps to reproduce
            validations:
              required: true
          - type: textarea
            id: expected
            attributes:
              label: Expected behavior
            validations:
              required: true
          - type: input
            id: version
            attributes:
              label: Version
              placeholder: v0.1.0
    ''',
    ".github/ISSUE_TEMPLATE/feature_request.yml": r'''
        name: Feature request
        description: Suggest an improvement for AURORA-FS
        title: "[feature]: "
        labels: ["enhancement"]
        body:
          - type: textarea
            id: problem
            attributes:
              label: Problem
            validations:
              required: true
          - type: textarea
            id: proposal
            attributes:
              label: Proposed solution
            validations:
              required: true
    ''',
    ".github/ISSUE_TEMPLATE/config.yml": r'''
        blank_issues_enabled: false
    ''',
    ".github/PULL_REQUEST_TEMPLATE.md": r'''
        ## Summary

        ## Security impact

        ## Format impact

        ## Tests added or updated
    ''',
    "scripts/lint.sh": r'''
        #!/usr/bin/env bash
        set -euo pipefail
        cargo fmt --all --check
        cargo clippy --workspace --all-targets -- -D warnings
        cargo test --workspace
    ''',
    "scripts/build_release.sh": r'''
        #!/usr/bin/env bash
        set -euo pipefail
        cargo fmt --all --check
        cargo clippy --workspace --all-targets -- -D warnings
        cargo test --workspace
        cargo install cargo-dist --locked
        cargo dist build
    ''',
    "scripts/publish_github.sh": r'''
        #!/usr/bin/env bash
        set -euo pipefail

        REPO_URL="${1:-}"
        if [[ -z "$REPO_URL" ]]; then
          echo "usage: scripts/publish_github.sh <git@github.com:USER/REPO.git|https://github.com/USER/REPO.git>"
          exit 1
        fi

        git init
        git add .
        git commit -m "Initial AURORA-FS import"
        git branch -M main
        git remote add origin "$REPO_URL"
        git push -u origin main

        echo
        echo "After push, GitHub will automatically offer Source code (zip)."
        echo "Optional next step: create a tag like v0.1.0 and push it."
    ''',
    "crates/aurora-fs-core/Cargo.toml": r'''
        [package]
        name = "aurora-fs-core"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [lib]
        path = "src/lib.rs"
    ''',
    "crates/aurora-fs-core/src/lib.rs": r'''
        pub mod chunk_table;
        pub mod errors;
        pub mod flags;
        pub mod header;
        pub mod metadata;
        pub mod slot;
        pub mod suite;
        pub mod version;

        pub use chunk_table::ChunkEntry;
        pub use errors::ParseError;
        pub use flags::{ChunkFlags, HeaderFlags};
        pub use header::{HeaderPrelude, MAGIC, PRELUDE_LEN};
        pub use metadata::{MetadataField, MetadataMap};
        pub use slot::{KeySlotHeader, KeySlotRecord};
        pub use suite::SuiteId;
        pub use version::FormatVersion;
    ''',
    "crates/aurora-fs-core/src/version.rs": r'''
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        pub struct FormatVersion {
            pub major: u8,
            pub minor: u8,
        }

        impl FormatVersion {
            pub const V1_0: Self = Self { major: 1, minor: 0 };
        }

        impl Default for FormatVersion {
            fn default() -> Self {
                Self::V1_0
            }
        }
    ''',
    "crates/aurora-fs-core/src/suite.rs": r'''
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        #[repr(u16)]
        pub enum SuiteId {
            Aes256GcmSiv = 0x0001,
            AesSiv = 0x0002,
            HardenedGcmSivChaCha20Poly1305 = 0x1001,
            HardenedGcmSivAesSiv = 0x1002,
        }

        impl SuiteId {
            pub fn from_u16(value: u16) -> Option<Self> {
                match value {
                    0x0001 => Some(Self::Aes256GcmSiv),
                    0x0002 => Some(Self::AesSiv),
                    0x1001 => Some(Self::HardenedGcmSivChaCha20Poly1305),
                    0x1002 => Some(Self::HardenedGcmSivAesSiv),
                    _ => None,
                }
            }

            pub fn as_u16(self) -> u16 {
                self as u16
            }
        }
    ''',
    "crates/aurora-fs-core/src/flags.rs": r'''
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
        pub struct HeaderFlags(pub u32);

        impl HeaderFlags {
            pub const METADATA_PRESENT: u32 = 1 << 0;
            pub const HARDENED_MODE: u32 = 1 << 1;
            pub const DETACHED_SIGNATURE_EXPECTED: u32 = 1 << 2;
            pub const ARMORED_EXPORT_COMPATIBLE: u32 = 1 << 3;
            pub const INTEGRITY_ONLY_ALLOWED: u32 = 1 << 4;

            pub fn contains(self, flag: u32) -> bool {
                self.0 & flag != 0
            }
        }

        #[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
        pub struct ChunkFlags(pub u32);

        impl ChunkFlags {
            pub const FINAL_CHUNK: u32 = 1 << 0;
            pub const ZERO_LENGTH_LOGICAL_CHUNK: u32 = 1 << 1;
        }
    ''',
    "crates/aurora-fs-core/src/errors.rs": r'''
        use std::fmt::{Display, Formatter};

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub enum ParseError {
            InvalidLength { expected_at_least: usize, actual: usize },
            InvalidMagic,
            UnsupportedSuite(u16),
            Truncated(&'static str),
            Inconsistent(&'static str),
        }

        impl Display for ParseError {
            fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
                match self {
                    Self::InvalidLength { expected_at_least, actual } => {
                        write!(f, "invalid length: expected at least {expected_at_least} bytes, got {actual}")
                    }
                    Self::InvalidMagic => write!(f, "invalid magic bytes"),
                    Self::UnsupportedSuite(id) => write!(f, "unsupported suite id: {id:#06x}"),
                    Self::Truncated(what) => write!(f, "truncated field: {what}"),
                    Self::Inconsistent(what) => write!(f, "inconsistent structure: {what}"),
                }
            }
        }

        impl std::error::Error for ParseError {}
    ''',
    "crates/aurora-fs-core/src/header.rs": r'''
        use crate::{errors::ParseError, flags::HeaderFlags, suite::SuiteId, version::FormatVersion};

        pub const MAGIC: &[u8; 8] = b"AURFS256";
        pub const PRELUDE_LEN: usize = 58;

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub struct HeaderPrelude {
            pub version: FormatVersion,
            pub suite_id: SuiteId,
            pub flags: HeaderFlags,
            pub chunk_size: u32,
            pub key_slot_count: u16,
            pub header_extension_length: u32,
            pub encrypted_metadata_length: u64,
            pub chunk_table_length: u64,
            pub reserved: [u8; 16],
        }

        impl Default for HeaderPrelude {
            fn default() -> Self {
                Self {
                    version: FormatVersion::default(),
                    suite_id: SuiteId::Aes256GcmSiv,
                    flags: HeaderFlags(0),
                    chunk_size: 4 * 1024 * 1024,
                    key_slot_count: 1,
                    header_extension_length: 0,
                    encrypted_metadata_length: 0,
                    chunk_table_length: 0,
                    reserved: [0u8; 16],
                }
            }
        }

        impl HeaderPrelude {
            pub fn to_bytes(&self) -> [u8; PRELUDE_LEN] {
                let mut out = [0u8; PRELUDE_LEN];
                let mut i = 0usize;
                out[i..i + 8].copy_from_slice(MAGIC);
                i += 8;
                out[i] = self.version.major;
                i += 1;
                out[i] = self.version.minor;
                i += 1;
                out[i..i + 2].copy_from_slice(&self.suite_id.as_u16().to_le_bytes());
                i += 2;
                out[i..i + 4].copy_from_slice(&self.flags.0.to_le_bytes());
                i += 4;
                out[i..i + 4].copy_from_slice(&self.chunk_size.to_le_bytes());
                i += 4;
                out[i..i + 2].copy_from_slice(&self.key_slot_count.to_le_bytes());
                i += 2;
                out[i..i + 4].copy_from_slice(&self.header_extension_length.to_le_bytes());
                i += 4;
                out[i..i + 8].copy_from_slice(&self.encrypted_metadata_length.to_le_bytes());
                i += 8;
                out[i..i + 8].copy_from_slice(&self.chunk_table_length.to_le_bytes());
                i += 8;
                out[i..i + 16].copy_from_slice(&self.reserved);
                out
            }

            pub fn from_bytes(bytes: &[u8]) -> Result<Self, ParseError> {
                if bytes.len() < PRELUDE_LEN {
                    return Err(ParseError::InvalidLength {
                        expected_at_least: PRELUDE_LEN,
                        actual: bytes.len(),
                    });
                }
                if &bytes[0..8] != MAGIC {
                    return Err(ParseError::InvalidMagic);
                }
                let version = FormatVersion {
                    major: bytes[8],
                    minor: bytes[9],
                };
                let suite = u16::from_le_bytes([bytes[10], bytes[11]]);
                let suite_id = SuiteId::from_u16(suite).ok_or(ParseError::UnsupportedSuite(suite))?;
                let flags = HeaderFlags(u32::from_le_bytes(bytes[12..16].try_into().expect("len")));
                let chunk_size = u32::from_le_bytes(bytes[16..20].try_into().expect("len"));
                let key_slot_count = u16::from_le_bytes(bytes[20..22].try_into().expect("len"));
                let header_extension_length = u32::from_le_bytes(bytes[22..26].try_into().expect("len"));
                let encrypted_metadata_length = u64::from_le_bytes(bytes[26..34].try_into().expect("len"));
                let chunk_table_length = u64::from_le_bytes(bytes[34..42].try_into().expect("len"));
                let reserved: [u8; 16] = bytes[42..58].try_into().expect("len");
                Ok(Self {
                    version,
                    suite_id,
                    flags,
                    chunk_size,
                    key_slot_count,
                    header_extension_length,
                    encrypted_metadata_length,
                    chunk_table_length,
                    reserved,
                })
            }
        }
    ''',
    "crates/aurora-fs-core/src/slot.rs": r'''
        use crate::errors::ParseError;

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub struct KeySlotHeader {
            pub slot_type: u8,
            pub kdf_id: u8,
            pub slot_flags: u16,
            pub salt_length: u16,
            pub kdf_param_length: u16,
            pub wrapped_key_length: u16,
            pub key_check_length: u16,
            pub slot_extension_length: u16,
        }

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub struct KeySlotRecord {
            pub header: KeySlotHeader,
            pub salt: Vec<u8>,
            pub kdf_params: Vec<u8>,
            pub wrapped_key: Vec<u8>,
            pub key_check: Vec<u8>,
            pub slot_extensions: Vec<u8>,
        }

        impl KeySlotRecord {
            pub fn encoded_len(&self) -> usize {
                14usize
                    + self.header.salt_length as usize
                    + self.header.kdf_param_length as usize
                    + self.header.wrapped_key_length as usize
                    + self.header.key_check_length as usize
                    + self.header.slot_extension_length as usize
            }

            pub fn encode(&self) -> Vec<u8> {
                let mut out = Vec::with_capacity(self.encoded_len());
                out.push(self.header.slot_type);
                out.push(self.header.kdf_id);
                out.extend_from_slice(&self.header.slot_flags.to_le_bytes());
                out.extend_from_slice(&self.header.salt_length.to_le_bytes());
                out.extend_from_slice(&self.header.kdf_param_length.to_le_bytes());
                out.extend_from_slice(&self.header.wrapped_key_length.to_le_bytes());
                out.extend_from_slice(&self.header.key_check_length.to_le_bytes());
                out.extend_from_slice(&self.header.slot_extension_length.to_le_bytes());
                out.extend_from_slice(&self.salt);
                out.extend_from_slice(&self.kdf_params);
                out.extend_from_slice(&self.wrapped_key);
                out.extend_from_slice(&self.key_check);
                out.extend_from_slice(&self.slot_extensions);
                out
            }

            pub fn decode(bytes: &[u8]) -> Result<Self, ParseError> {
                if bytes.len() < 14 {
                    return Err(ParseError::InvalidLength { expected_at_least: 14, actual: bytes.len() });
                }
                let header = KeySlotHeader {
                    slot_type: bytes[0],
                    kdf_id: bytes[1],
                    slot_flags: u16::from_le_bytes([bytes[2], bytes[3]]),
                    salt_length: u16::from_le_bytes([bytes[4], bytes[5]]),
                    kdf_param_length: u16::from_le_bytes([bytes[6], bytes[7]]),
                    wrapped_key_length: u16::from_le_bytes([bytes[8], bytes[9]]),
                    key_check_length: u16::from_le_bytes([bytes[10], bytes[11]]),
                    slot_extension_length: u16::from_le_bytes([bytes[12], bytes[13]]),
                };
                let total = 14usize
                    + header.salt_length as usize
                    + header.kdf_param_length as usize
                    + header.wrapped_key_length as usize
                    + header.key_check_length as usize
                    + header.slot_extension_length as usize;
                if bytes.len() < total {
                    return Err(ParseError::InvalidLength { expected_at_least: total, actual: bytes.len() });
                }
                let mut i = 14usize;
                let salt = bytes[i..i + header.salt_length as usize].to_vec();
                i += header.salt_length as usize;
                let kdf_params = bytes[i..i + header.kdf_param_length as usize].to_vec();
                i += header.kdf_param_length as usize;
                let wrapped_key = bytes[i..i + header.wrapped_key_length as usize].to_vec();
                i += header.wrapped_key_length as usize;
                let key_check = bytes[i..i + header.key_check_length as usize].to_vec();
                i += header.key_check_length as usize;
                let slot_extensions = bytes[i..i + header.slot_extension_length as usize].to_vec();
                Ok(Self { header, salt, kdf_params, wrapped_key, key_check, slot_extensions })
            }
        }
    ''',
    "crates/aurora-fs-core/src/metadata.rs": r'''
        #[derive(Debug, Clone, PartialEq, Eq)]
        pub struct MetadataField {
            pub field_type: u8,
            pub flags: u8,
            pub value: Vec<u8>,
        }

        #[derive(Debug, Clone, PartialEq, Eq, Default)]
        pub struct MetadataMap {
            pub fields: Vec<MetadataField>,
        }
    ''',
    "crates/aurora-fs-core/src/chunk_table.rs": r'''
        use crate::{errors::ParseError, flags::ChunkFlags};

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub struct ChunkEntry {
            pub chunk_index: u64,
            pub plaintext_length: u32,
            pub ciphertext_length: u32,
            pub ciphertext_offset: u64,
            pub flags: ChunkFlags,
            pub reserved: u32,
        }

        impl ChunkEntry {
            pub const ENCODED_LEN: usize = 32;

            pub fn encode(&self) -> [u8; Self::ENCODED_LEN] {
                let mut out = [0u8; Self::ENCODED_LEN];
                out[0..8].copy_from_slice(&self.chunk_index.to_le_bytes());
                out[8..12].copy_from_slice(&self.plaintext_length.to_le_bytes());
                out[12..16].copy_from_slice(&self.ciphertext_length.to_le_bytes());
                out[16..24].copy_from_slice(&self.ciphertext_offset.to_le_bytes());
                out[24..28].copy_from_slice(&self.flags.0.to_le_bytes());
                out[28..32].copy_from_slice(&self.reserved.to_le_bytes());
                out
            }

            pub fn decode(bytes: &[u8]) -> Result<Self, ParseError> {
                if bytes.len() < Self::ENCODED_LEN {
                    return Err(ParseError::InvalidLength {
                        expected_at_least: Self::ENCODED_LEN,
                        actual: bytes.len(),
                    });
                }
                Ok(Self {
                    chunk_index: u64::from_le_bytes(bytes[0..8].try_into().expect("len")),
                    plaintext_length: u32::from_le_bytes(bytes[8..12].try_into().expect("len")),
                    ciphertext_length: u32::from_le_bytes(bytes[12..16].try_into().expect("len")),
                    ciphertext_offset: u64::from_le_bytes(bytes[16..24].try_into().expect("len")),
                    flags: ChunkFlags(u32::from_le_bytes(bytes[24..28].try_into().expect("len"))),
                    reserved: u32::from_le_bytes(bytes[28..32].try_into().expect("len")),
                })
            }
        }
    ''',
    "crates/aurora-fs-crypto/Cargo.toml": r'''
        [package]
        name = "aurora-fs-crypto"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [dependencies]
        aes-gcm-siv.workspace = true
        aes-keywrap.workspace = true
        getrandom.workspace = true
        tiny-keccak.workspace = true
        zeroize.workspace = true

        [lib]
        path = "src/lib.rs"
    ''',
    "crates/aurora-fs-crypto/src/lib.rs": r'''
        pub mod aad;
        pub mod aead;
        pub mod derive;
        pub mod rng;
        pub mod wrap;
        pub mod zeroize_support;

        pub use aad::build_chunk_aad;
        pub use aead::{AeadSuite, Aes256GcmSivBackend, CryptoError};
        pub use derive::{DeriveEngine, Kmac256Derive};
        pub use rng::{OsRandomSource, RandomSource};
        pub use wrap::{Aes256KwpWrapEngine, WrapEngine};
    ''',
    "crates/aurora-fs-crypto/src/aad.rs": r'''
        pub fn build_chunk_aad(header_binding: &[u8], chunk_index: u64, plaintext_length: u32) -> Vec<u8> {
            let mut out = Vec::with_capacity(header_binding.len() + 8 + 4);
            out.extend_from_slice(header_binding);
            out.extend_from_slice(&chunk_index.to_le_bytes());
            out.extend_from_slice(&plaintext_length.to_le_bytes());
            out
        }
    ''',
    "crates/aurora-fs-crypto/src/aead.rs": r'''
        use std::fmt::{Display, Formatter};

        use aes_gcm_siv::{
            aead::{Aead, KeyInit, Payload},
            Aes256GcmSiv, Nonce,
        };

        #[derive(Debug)]
        pub enum CryptoError {
            Unsupported(&'static str),
            InvalidInput(&'static str),
            RandomFailure(&'static str),
            AuthFailure(&'static str),
        }

        impl Display for CryptoError {
            fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
                match self {
                    Self::Unsupported(what) => write!(f, "unsupported crypto operation: {what}"),
                    Self::InvalidInput(what) => write!(f, "invalid crypto input: {what}"),
                    Self::RandomFailure(what) => write!(f, "randomness failure: {what}"),
                    Self::AuthFailure(what) => write!(f, "authentication failure: {what}"),
                }
            }
        }

        impl std::error::Error for CryptoError {}

        pub trait AeadSuite {
            fn encrypt(&self, key: &[u8], nonce: &[u8], plaintext: &[u8], aad: &[u8]) -> Result<Vec<u8>, CryptoError>;
            fn decrypt(&self, key: &[u8], nonce: &[u8], ciphertext: &[u8], aad: &[u8]) -> Result<Vec<u8>, CryptoError>;
        }

        #[derive(Debug, Default)]
        pub struct Aes256GcmSivBackend;

        impl AeadSuite for Aes256GcmSivBackend {
            fn encrypt(&self, key: &[u8], nonce: &[u8], plaintext: &[u8], aad: &[u8]) -> Result<Vec<u8>, CryptoError> {
                if key.len() != 32 {
                    return Err(CryptoError::InvalidInput("AES-256-GCM-SIV requires a 32-byte key"));
                }
                if nonce.len() != 12 {
                    return Err(CryptoError::InvalidInput("AES-256-GCM-SIV requires a 12-byte nonce"));
                }
                let cipher = Aes256GcmSiv::new_from_slice(key).map_err(|_| CryptoError::InvalidInput("failed to initialize AES-256-GCM-SIV"))?;
                let payload = Payload { msg: plaintext, aad };
                cipher.encrypt(Nonce::from_slice(nonce), payload).map_err(|_| CryptoError::AuthFailure("encrypt failed"))
            }

            fn decrypt(&self, key: &[u8], nonce: &[u8], ciphertext: &[u8], aad: &[u8]) -> Result<Vec<u8>, CryptoError> {
                if key.len() != 32 {
                    return Err(CryptoError::InvalidInput("AES-256-GCM-SIV requires a 32-byte key"));
                }
                if nonce.len() != 12 {
                    return Err(CryptoError::InvalidInput("AES-256-GCM-SIV requires a 12-byte nonce"));
                }
                let cipher = Aes256GcmSiv::new_from_slice(key).map_err(|_| CryptoError::InvalidInput("failed to initialize AES-256-GCM-SIV"))?;
                let payload = Payload { msg: ciphertext, aad };
                cipher.decrypt(Nonce::from_slice(nonce), payload).map_err(|_| CryptoError::AuthFailure("decrypt failed"))
            }
        }
    ''',
    "crates/aurora-fs-crypto/src/derive.rs": r'''
        use tiny_keccak::{IntoXof, Kmac, Xof};

        use crate::aead::CryptoError;

        pub trait DeriveEngine {
            fn derive(&self, customization: &[u8], input_key_material: &[u8], context: &[u8], out_len: usize) -> Result<Vec<u8>, CryptoError>;
        }

        #[derive(Debug, Default)]
        pub struct Kmac256Derive;

        impl DeriveEngine for Kmac256Derive {
            fn derive(&self, customization: &[u8], input_key_material: &[u8], context: &[u8], out_len: usize) -> Result<Vec<u8>, CryptoError> {
                if input_key_material.is_empty() {
                    return Err(CryptoError::InvalidInput("KMAC input key material must not be empty"));
                }
                if out_len == 0 {
                    return Err(CryptoError::InvalidInput("derived output length must be non-zero"));
                }
                let mut kmac = Kmac::v256(input_key_material, customization);
                kmac.update(context);
                let mut xof = kmac.into_xof();
                let mut out = vec![0u8; out_len];
                xof.squeeze(&mut out);
                Ok(out)
            }
        }
    ''',
    "crates/aurora-fs-crypto/src/rng.rs": r'''
        use crate::aead::CryptoError;

        pub trait RandomSource {
            fn fill(&self, buf: &mut [u8]) -> Result<(), CryptoError>;
        }

        #[derive(Debug, Default)]
        pub struct OsRandomSource;

        impl RandomSource for OsRandomSource {
            fn fill(&self, buf: &mut [u8]) -> Result<(), CryptoError> {
                getrandom::fill(buf).map_err(|_| CryptoError::RandomFailure("OS RNG failed"))
            }
        }
    ''',
    "crates/aurora-fs-crypto/src/wrap.rs": r'''
        use aes_keywrap::Aes256KeyWrap;

        use crate::aead::CryptoError;

        pub trait WrapEngine {
            fn wrap_key(&self, wrapping_key: &[u8], content_key: &[u8]) -> Result<Vec<u8>, CryptoError>;
            fn unwrap_key(&self, wrapping_key: &[u8], wrapped_key: &[u8], expected_plaintext_len: usize) -> Result<Vec<u8>, CryptoError>;
        }

        #[derive(Debug, Default)]
        pub struct Aes256KwpWrapEngine;

        impl WrapEngine for Aes256KwpWrapEngine {
            fn wrap_key(&self, wrapping_key: &[u8], content_key: &[u8]) -> Result<Vec<u8>, CryptoError> {
                if wrapping_key.len() != 32 {
                    return Err(CryptoError::InvalidInput("AES-KWP requires a 32-byte wrapping key"));
                }
                let mut kek = [0u8; 32];
                kek.copy_from_slice(wrapping_key);
                let kw = Aes256KeyWrap::new(&kek);
                kw.encapsulate(content_key).map_err(|_| CryptoError::AuthFailure("key wrap failed"))
            }

            fn unwrap_key(&self, wrapping_key: &[u8], wrapped_key: &[u8], expected_plaintext_len: usize) -> Result<Vec<u8>, CryptoError> {
                if wrapping_key.len() != 32 {
                    return Err(CryptoError::InvalidInput("AES-KWP requires a 32-byte wrapping key"));
                }
                let mut kek = [0u8; 32];
                kek.copy_from_slice(wrapping_key);
                let kw = Aes256KeyWrap::new(&kek);
                kw.decapsulate(wrapped_key, expected_plaintext_len).map_err(|_| CryptoError::AuthFailure("key unwrap failed"))
            }
        }
    ''',
    "crates/aurora-fs-crypto/src/zeroize_support.rs": r'''
        use zeroize::Zeroize;

        pub fn zeroize_bytes(bytes: &mut [u8]) {
            bytes.zeroize();
        }
    ''',
    "crates/aurora-fs-kdf/Cargo.toml": r'''
        [package]
        name = "aurora-fs-kdf"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [dependencies]
        argon2.workspace = true

        [lib]
        path = "src/lib.rs"
    ''',
    "crates/aurora-fs-kdf/src/lib.rs": r'''
        pub mod argon2id;
        pub mod calibrate;
        pub mod params;
        pub mod policy;
        pub mod presets;

        pub use argon2id::{derive_slot_key, KdfError};
        pub use calibrate::{calibrate_for_host, CalibrationProfile};
        pub use params::Argon2Params;
        pub use presets::{memory_constrained_preset, portable_preset, strong_desktop_preset};
    ''',
    "crates/aurora-fs-kdf/src/params.rs": r'''
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        pub struct Argon2Params {
            pub memory_kib: u32,
            pub iterations: u32,
            pub parallelism: u32,
            pub output_length: u32,
        }
    ''',
    "crates/aurora-fs-kdf/src/presets.rs": r'''
        use crate::params::Argon2Params;

        pub fn strong_desktop_preset() -> Argon2Params {
            Argon2Params { memory_kib: 2 * 1024 * 1024, iterations: 1, parallelism: 4, output_length: 32 }
        }

        pub fn portable_preset() -> Argon2Params {
            Argon2Params { memory_kib: 256 * 1024, iterations: 2, parallelism: 4, output_length: 32 }
        }

        pub fn memory_constrained_preset() -> Argon2Params {
            Argon2Params { memory_kib: 64 * 1024, iterations: 3, parallelism: 4, output_length: 32 }
        }
    ''',
    "crates/aurora-fs-kdf/src/calibrate.rs": r'''
        use crate::{params::Argon2Params, presets::{memory_constrained_preset, portable_preset, strong_desktop_preset}};

        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        pub enum CalibrationProfile {
            StrongDesktop,
            Portable,
            MemoryConstrained,
        }

        pub fn calibrate_for_host(profile: CalibrationProfile) -> Argon2Params {
            match profile {
                CalibrationProfile::StrongDesktop => strong_desktop_preset(),
                CalibrationProfile::Portable => portable_preset(),
                CalibrationProfile::MemoryConstrained => memory_constrained_preset(),
            }
        }
    ''',
    "crates/aurora-fs-kdf/src/policy.rs": r'''
        use crate::params::Argon2Params;

        pub fn validate_params(params: Argon2Params) -> Result<Argon2Params, &'static str> {
            if params.memory_kib < 64 * 1024 { return Err("memory_kib below implementation minimum"); }
            if params.iterations == 0 { return Err("iterations must be non-zero"); }
            if params.parallelism == 0 { return Err("parallelism must be non-zero"); }
            if params.output_length < 32 { return Err("output_length must be at least 32 bytes"); }
            Ok(params)
        }
    ''',
    "crates/aurora-fs-kdf/src/argon2id.rs": r'''
        use std::fmt::{Display, Formatter};

        use argon2::{Algorithm, Argon2, Params, Version};

        use crate::{params::Argon2Params, policy::validate_params};

        #[derive(Debug)]
        pub enum KdfError {
            InvalidPolicy(&'static str),
            DerivationFailed,
        }

        impl Display for KdfError {
            fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
                match self {
                    Self::InvalidPolicy(msg) => write!(f, "invalid KDF policy: {msg}"),
                    Self::DerivationFailed => write!(f, "Argon2id derivation failed"),
                }
            }
        }

        impl std::error::Error for KdfError {}

        pub fn derive_slot_key(passphrase: &[u8], salt: &[u8], params: Argon2Params) -> Result<Vec<u8>, KdfError> {
            let params = validate_params(params).map_err(KdfError::InvalidPolicy)?;
            if salt.len() < 8 {
                return Err(KdfError::InvalidPolicy("salt must be at least 8 bytes"));
            }
            let argon_params = Params::new(
                params.memory_kib,
                params.iterations,
                params.parallelism,
                Some(params.output_length as usize),
            )
            .map_err(|_| KdfError::DerivationFailed)?;
            let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, argon_params);
            let mut out = vec![0u8; params.output_length as usize];
            argon2.hash_password_into(passphrase, salt, &mut out).map_err(|_| KdfError::DerivationFailed)?;
            Ok(out)
        }
    ''',
    "crates/aurora-fs-container/Cargo.toml": r'''
        [package]
        name = "aurora-fs-container"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [dependencies]
        aurora-fs-core = { path = "../aurora-fs-core" }
        aurora-fs-crypto = { path = "../aurora-fs-crypto" }

        [lib]
        path = "src/lib.rs"
    ''',
    "crates/aurora-fs-container/src/lib.rs": r'''
        use std::fmt::{Display, Formatter};
        use std::path::Path;

        use aurora_fs_core::{ChunkEntry, ChunkFlags, HeaderPrelude, HeaderFlags, KeySlotHeader, KeySlotRecord, ParseError, SuiteId, PRELUDE_LEN};
        use aurora_fs_crypto::{
            build_chunk_aad,
            AeadSuite,
            Aes256GcmSivBackend,
            Aes256KwpWrapEngine,
            DeriveEngine,
            Kmac256Derive,
            OsRandomSource,
            RandomSource,
            WrapEngine,
        };

        #[derive(Debug, Clone, PartialEq, Eq)]
        pub enum EncryptionMode {
            Standard,
            Hardened,
        }

        #[derive(Debug, Clone)]
        pub struct EncryptOptions {
            pub suite: SuiteId,
            pub chunk_size: u32,
            pub mode: EncryptionMode,
        }

        impl Default for EncryptOptions {
            fn default() -> Self {
                Self { suite: SuiteId::Aes256GcmSiv, chunk_size: 4 * 1024 * 1024, mode: EncryptionMode::Standard }
            }
        }

        #[derive(Debug, Clone, Default)]
        pub struct DecryptOptions {
            pub overwrite: bool,
        }

        #[derive(Debug, Clone)]
        pub enum UnlockMaterial {
            KeyFile(Vec<u8>),
            Passphrase(String),
            PassphraseAndKeyFile { passphrase: String, key_file: Vec<u8> },
        }

        #[derive(Debug, Clone)]
        pub struct EncryptReport {
            pub output_path: String,
            pub chunk_count: usize,
        }

        #[derive(Debug, Clone)]
        pub struct DecryptReport {
            pub output_path: String,
            pub chunk_count: usize,
        }

        #[derive(Debug, Clone)]
        pub struct InspectReport {
            pub version_major: u8,
            pub version_minor: u8,
            pub suite: SuiteId,
            pub chunk_size: u32,
            pub key_slot_count: u16,
            pub metadata_present: bool,
        }

        #[derive(Debug)]
        pub enum ContainerError {
            Io(std::io::Error),
            Parse(ParseError),
            Crypto(&'static str),
            UnsupportedOperation(&'static str),
            InvalidState(&'static str),
        }

        impl Display for ContainerError {
            fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
                match self {
                    Self::Io(e) => write!(f, "I/O error: {e}"),
                    Self::Parse(e) => write!(f, "parse error: {e}"),
                    Self::Crypto(msg) => write!(f, "crypto error: {msg}"),
                    Self::UnsupportedOperation(msg) => write!(f, "unsupported operation: {msg}"),
                    Self::InvalidState(msg) => write!(f, "invalid state: {msg}"),
                }
            }
        }

        impl std::error::Error for ContainerError {}

        impl From<std::io::Error> for ContainerError {
            fn from(value: std::io::Error) -> Self { Self::Io(value) }
        }

        impl From<ParseError> for ContainerError {
            fn from(value: ParseError) -> Self { Self::Parse(value) }
        }

        fn derive_wrapping_key(keyfile: &[u8]) -> Result<Vec<u8>, ContainerError> {
            let derive = Kmac256Derive;
            derive.derive(b"aurora-slot-wrap-v1", keyfile, b"keyfile-wrap", 32).map_err(|_| ContainerError::Crypto("failed to derive wrapping key"))
        }

        fn derive_header_binding(file_key: &[u8], public_header: &[u8]) -> Result<Vec<u8>, ContainerError> {
            let derive = Kmac256Derive;
            derive.derive(b"aurora-header-bind-v1", file_key, public_header, 32).map_err(|_| ContainerError::Crypto("failed to derive header binding"))
        }

        fn derive_chunk_key_and_nonce(file_key: &[u8], header_binding: &[u8], chunk_index: u64) -> Result<(Vec<u8>, Vec<u8>), ContainerError> {
            let derive = Kmac256Derive;
            let mut context = Vec::with_capacity(header_binding.len() + 8);
            context.extend_from_slice(header_binding);
            context.extend_from_slice(&chunk_index.to_le_bytes());
            let key = derive.derive(b"aurora-chunk-key-v1", file_key, &context, 32).map_err(|_| ContainerError::Crypto("failed to derive chunk key"))?;
            let nonce = derive.derive(b"aurora-chunk-nonce-v1", file_key, &context, 12).map_err(|_| ContainerError::Crypto("failed to derive chunk nonce"))?;
            Ok((key, nonce))
        }

        fn parse_slots(bytes: &[u8], count: u16) -> Result<(Vec<KeySlotRecord>, usize), ContainerError> {
            let mut slots = Vec::with_capacity(count as usize);
            let mut cursor = 0usize;
            for _ in 0..count {
                let slot = KeySlotRecord::decode(&bytes[cursor..])?;
                let consumed = slot.encoded_len();
                cursor += consumed;
                slots.push(slot);
            }
            Ok((slots, cursor))
        }

        fn unlock_file_key(slots: &[KeySlotRecord], unlock: UnlockMaterial) -> Result<Vec<u8>, ContainerError> {
            match unlock {
                UnlockMaterial::KeyFile(keyfile) => {
                    let wrapping_key = derive_wrapping_key(&keyfile)?;
                    let wrap = Aes256KwpWrapEngine;
                    let slot = slots.iter().find(|slot| slot.header.slot_type == 0x02 && slot.header.kdf_id == 0xFF).ok_or(ContainerError::UnsupportedOperation("no supported key-file slot found"))?;
                    wrap.unwrap_key(&wrapping_key, &slot.wrapped_key, 32).map_err(|_| ContainerError::Crypto("key unwrap failed"))
                }
                UnlockMaterial::Passphrase(_) => Err(ContainerError::UnsupportedOperation("passphrase unlock not integrated yet")),
                UnlockMaterial::PassphraseAndKeyFile { .. } => Err(ContainerError::UnsupportedOperation("hybrid unlock not integrated yet")),
            }
        }

        pub fn encrypt_path(input: &Path, output: &Path, unlock: UnlockMaterial, opts: EncryptOptions) -> Result<EncryptReport, ContainerError> {
            if opts.mode != EncryptionMode::Standard {
                return Err(ContainerError::UnsupportedOperation("hardened mode not integrated yet"));
            }
            if opts.suite != SuiteId::Aes256GcmSiv {
                return Err(ContainerError::UnsupportedOperation("only AES-256-GCM-SIV standard mode is integrated"));
            }
            let keyfile = match unlock {
                UnlockMaterial::KeyFile(bytes) => bytes,
                UnlockMaterial::Passphrase(_) => return Err(ContainerError::UnsupportedOperation("passphrase unlock not integrated yet")),
                UnlockMaterial::PassphraseAndKeyFile { .. } => return Err(ContainerError::UnsupportedOperation("hybrid unlock not integrated yet")),
            };
            if opts.chunk_size == 0 {
                return Err(ContainerError::InvalidState("chunk size must be non-zero"));
            }

            let plaintext = std::fs::read(input)?;
            let rng = OsRandomSource;
            let mut file_key = vec![0u8; 32];
            rng.fill(&mut file_key).map_err(|_| ContainerError::Crypto("failed to generate file key"))?;

            let wrapping_key = derive_wrapping_key(&keyfile)?;
            let wrap = Aes256KwpWrapEngine;
            let wrapped_key = wrap.wrap_key(&wrapping_key, &file_key).map_err(|_| ContainerError::Crypto("failed to wrap file key"))?;

            let slot = KeySlotRecord {
                header: KeySlotHeader {
                    slot_type: 0x02,
                    kdf_id: 0xFF,
                    slot_flags: 0,
                    salt_length: 0,
                    kdf_param_length: 0,
                    wrapped_key_length: wrapped_key.len() as u16,
                    key_check_length: 0,
                    slot_extension_length: 0,
                },
                salt: Vec::new(),
                kdf_params: Vec::new(),
                wrapped_key,
                key_check: Vec::new(),
                slot_extensions: Vec::new(),
            };
            let slot_bytes = slot.encode();

            let chunk_count = if plaintext.is_empty() { 1usize } else { plaintext.len().div_ceil(opts.chunk_size as usize) };

            let prelude = HeaderPrelude {
                chunk_size: opts.chunk_size,
                key_slot_count: 1,
                chunk_table_length: (chunk_count * ChunkEntry::ENCODED_LEN) as u64,
                ..HeaderPrelude::default()
            };
            let prelude_bytes = prelude.to_bytes();
            let mut public_header = Vec::with_capacity(prelude_bytes.len() + slot_bytes.len());
            public_header.extend_from_slice(&prelude_bytes);
            public_header.extend_from_slice(&slot_bytes);
            let header_binding = derive_header_binding(&file_key, &public_header)?;

            let aead = Aes256GcmSivBackend;
            let mut chunk_table = Vec::with_capacity(chunk_count);
            let mut ciphertext_stream = Vec::new();

            for chunk_index in 0..chunk_count {
                let start = chunk_index * opts.chunk_size as usize;
                let end = std::cmp::min(start + opts.chunk_size as usize, plaintext.len());
                let chunk_plaintext = if plaintext.is_empty() { &[][..] } else { &plaintext[start..end] };
                let (chunk_key, chunk_nonce) = derive_chunk_key_and_nonce(&file_key, &header_binding, chunk_index as u64)?;
                let aad = build_chunk_aad(&header_binding, chunk_index as u64, chunk_plaintext.len() as u32);
                let ciphertext = aead.encrypt(&chunk_key, &chunk_nonce, chunk_plaintext, &aad).map_err(|_| ContainerError::Crypto("chunk encryption failed"))?;
                let flags = if chunk_index + 1 == chunk_count {
                    if chunk_plaintext.is_empty() { ChunkFlags(ChunkFlags::FINAL_CHUNK | ChunkFlags::ZERO_LENGTH_LOGICAL_CHUNK) } else { ChunkFlags(ChunkFlags::FINAL_CHUNK) }
                } else {
                    ChunkFlags(0)
                };
                chunk_table.push(ChunkEntry {
                    chunk_index: chunk_index as u64,
                    plaintext_length: chunk_plaintext.len() as u32,
                    ciphertext_length: ciphertext.len() as u32,
                    ciphertext_offset: ciphertext_stream.len() as u64,
                    flags,
                    reserved: 0,
                });
                ciphertext_stream.extend_from_slice(&ciphertext);
            }

            let mut chunk_table_bytes = Vec::with_capacity(chunk_count * ChunkEntry::ENCODED_LEN);
            for entry in &chunk_table {
                chunk_table_bytes.extend_from_slice(&entry.encode());
            }

            let mut out = Vec::with_capacity(prelude_bytes.len() + slot_bytes.len() + chunk_table_bytes.len() + ciphertext_stream.len());
            out.extend_from_slice(&prelude_bytes);
            out.extend_from_slice(&slot_bytes);
            out.extend_from_slice(&chunk_table_bytes);
            out.extend_from_slice(&ciphertext_stream);
            std::fs::write(output, out)?;
            Ok(EncryptReport { output_path: output.display().to_string(), chunk_count })
        }

        pub fn decrypt_path(input: &Path, output: &Path, unlock: UnlockMaterial, _opts: DecryptOptions) -> Result<DecryptReport, ContainerError> {
            let bytes = std::fs::read(input)?;
            let prelude = HeaderPrelude::from_bytes(&bytes)?;
            if prelude.suite_id != SuiteId::Aes256GcmSiv {
                return Err(ContainerError::UnsupportedOperation("only AES-256-GCM-SIV standard mode is integrated"));
            }
            let after_prelude = &bytes[PRELUDE_LEN..];
            let (slots, slot_bytes_len) = parse_slots(after_prelude, prelude.key_slot_count)?;
            let header_extensions_start = PRELUDE_LEN + slot_bytes_len;
            let header_extensions_end = header_extensions_start + prelude.header_extension_length as usize;
            let metadata_start = header_extensions_end;
            let metadata_end = metadata_start + prelude.encrypted_metadata_length as usize;
            let chunk_table_start = metadata_end;
            let chunk_table_end = chunk_table_start + prelude.chunk_table_length as usize;
            if chunk_table_end > bytes.len() {
                return Err(ContainerError::Parse(ParseError::Truncated("chunk table region")));
            }
            if prelude.chunk_table_length as usize % ChunkEntry::ENCODED_LEN != 0 {
                return Err(ContainerError::Parse(ParseError::Inconsistent("chunk table length not aligned")));
            }
            let ciphertext_stream_start = chunk_table_end;

            let public_header = &bytes[..header_extensions_end];
            let file_key = unlock_file_key(&slots, unlock)?;
            let header_binding = derive_header_binding(&file_key, public_header)?;

            let chunk_count = prelude.chunk_table_length as usize / ChunkEntry::ENCODED_LEN;
            let mut chunk_entries = Vec::with_capacity(chunk_count);
            for i in 0..chunk_count {
                let start = chunk_table_start + i * ChunkEntry::ENCODED_LEN;
                let end = start + ChunkEntry::ENCODED_LEN;
                chunk_entries.push(ChunkEntry::decode(&bytes[start..end])?);
            }

            let aead = Aes256GcmSivBackend;
            let mut plaintext = Vec::new();
            for entry in &chunk_entries {
                let ct_start = ciphertext_stream_start + entry.ciphertext_offset as usize;
                let ct_end = ct_start + entry.ciphertext_length as usize;
                if ct_end > bytes.len() {
                    return Err(ContainerError::Parse(ParseError::Truncated("ciphertext chunk")));
                }
                let ciphertext = &bytes[ct_start..ct_end];
                let (chunk_key, chunk_nonce) = derive_chunk_key_and_nonce(&file_key, &header_binding, entry.chunk_index)?;
                let aad = build_chunk_aad(&header_binding, entry.chunk_index, entry.plaintext_length);
                let chunk_plaintext = aead.decrypt(&chunk_key, &chunk_nonce, ciphertext, &aad).map_err(|_| ContainerError::Crypto("decryption failed"))?;
                if chunk_plaintext.len() != entry.plaintext_length as usize {
                    return Err(ContainerError::Parse(ParseError::Inconsistent("plaintext length mismatch")));
                }
                plaintext.extend_from_slice(&chunk_plaintext);
            }

            std::fs::write(output, plaintext)?;
            Ok(DecryptReport { output_path: output.display().to_string(), chunk_count })
        }

        pub fn inspect_path(input: &Path) -> Result<InspectReport, ContainerError> {
            let bytes = std::fs::read(input)?;
            let prelude = HeaderPrelude::from_bytes(&bytes)?;
            Ok(InspectReport {
                version_major: prelude.version.major,
                version_minor: prelude.version.minor,
                suite: prelude.suite_id,
                chunk_size: prelude.chunk_size,
                key_slot_count: prelude.key_slot_count,
                metadata_present: prelude.flags.contains(HeaderFlags::METADATA_PRESENT),
            })
        }
    ''',
    "crates/aurora-fs-cli/Cargo.toml": r'''
        [package]
        name = "aurora-fs-cli"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [dependencies]
        aurora-fs-container = { path = "../aurora-fs-container" }
        aurora-fs-crypto = { path = "../aurora-fs-crypto" }
        aurora-fs-core = { path = "../aurora-fs-core" }
        base64.workspace = true
        clap.workspace = true

        [[bin]]
        name = "aurora"
        path = "src/main.rs"
    ''',
    "crates/aurora-fs-cli/src/main.rs": r'''
        mod cli;
        mod cmd_decrypt;
        mod cmd_encrypt;
        mod cmd_info;
        mod cmd_keyarmor;
        mod cmd_keygen;
        mod cmd_rekey;
        mod cmd_verify;
        mod exitcodes;
        mod output;

        use clap::Parser;
        use exitcodes::ExitCode;

        fn main() {
            let cli = cli::Cli::parse();
            let code = match cli::dispatch(cli) {
                Ok(()) => ExitCode::Success,
                Err(code) => code,
            };
            std::process::exit(code as i32);
        }
    ''',
    "crates/aurora-fs-cli/src/cli.rs": r'''
        use std::path::PathBuf;

        use clap::{Parser, Subcommand};

        use crate::exitcodes::ExitCode;

        #[derive(Debug, Parser)]
        #[command(name = "aurora", about = "AURORA-FS CLI")]
        pub struct Cli {
            #[command(subcommand)]
            pub command: Command,
        }

        #[derive(Debug, Subcommand)]
        pub enum Command {
            Encrypt {
                input: PathBuf,
                #[arg(short, long)]
                output: Option<PathBuf>,
                #[arg(long)]
                key_file: PathBuf,
                #[arg(long, default_value_t = 4 * 1024 * 1024)]
                chunk_size: u32,
            },
            Decrypt {
                input: PathBuf,
                #[arg(short, long)]
                output: Option<PathBuf>,
                #[arg(long)]
                key_file: PathBuf,
            },
            Rekey {
                input: PathBuf,
                #[arg(short, long)]
                output: Option<PathBuf>,
            },
            Info {
                input: PathBuf,
            },
            Verify {
                input: PathBuf,
            },
            Keygen {
                #[arg(short, long)]
                output: PathBuf,
                #[arg(long, default_value_t = 32)]
                size: usize,
                #[arg(long)]
                overwrite: bool,
            },
            Keyarmor {
                #[command(subcommand)]
                action: KeyArmorAction,
            },
        }

        #[derive(Debug, Subcommand)]
        pub enum KeyArmorAction {
            Export {
                input: PathBuf,
                #[arg(short, long)]
                output: PathBuf,
                #[arg(long)]
                overwrite: bool,
            },
            Import {
                input: PathBuf,
                #[arg(short, long)]
                output: PathBuf,
                #[arg(long)]
                overwrite: bool,
            },
        }

        pub fn dispatch(cli: Cli) -> Result<(), ExitCode> {
            match cli.command {
                Command::Encrypt { input, output, key_file, chunk_size } => crate::cmd_encrypt::run(input, output, key_file, chunk_size),
                Command::Decrypt { input, output, key_file } => crate::cmd_decrypt::run(input, output, key_file),
                Command::Rekey { input, output } => crate::cmd_rekey::run(input, output),
                Command::Info { input } => crate::cmd_info::run(input),
                Command::Verify { input } => crate::cmd_verify::run(input),
                Command::Keygen { output, size, overwrite } => crate::cmd_keygen::run(output, size, overwrite),
                Command::Keyarmor { action } => crate::cmd_keyarmor::run(action),
            }
        }
    ''',
    "crates/aurora-fs-cli/src/exitcodes.rs": r'''
        #[repr(i32)]
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        pub enum ExitCode {
            Success = 0,
            Generic = 1,
            MalformedInput = 2,
            WrongKeyOrAuthFailure = 3,
            Unsupported = 4,
            UnsafePolicyRefusal = 5,
            IoFailure = 6,
        }
    ''',
    "crates/aurora-fs-cli/src/output.rs": r'''
        pub fn print_line(message: &str) {
            println!("{message}");
        }

        pub fn print_error(message: &str) {
            eprintln!("{message}");
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_encrypt.rs": r'''
        use std::path::PathBuf;

        use aurora_fs_container::{encrypt_path, EncryptOptions, EncryptionMode, SuiteId, UnlockMaterial};

        use crate::{exitcodes::ExitCode, output::{print_error, print_line}};

        pub fn run(input: PathBuf, output: Option<PathBuf>, key_file: PathBuf, chunk_size: u32) -> Result<(), ExitCode> {
            let key_bytes = std::fs::read(&key_file).map_err(|err| {
                print_error(&format!("encrypt: failed to read key file: {err}"));
                ExitCode::IoFailure
            })?;
            let out = output.unwrap_or_else(|| input.with_extension("aur"));
            let opts = EncryptOptions { suite: SuiteId::Aes256GcmSiv, chunk_size, mode: EncryptionMode::Standard };
            match encrypt_path(&input, &out, UnlockMaterial::KeyFile(key_bytes), opts) {
                Ok(report) => {
                    print_line(&format!("encrypted: {} ({} chunks)", report.output_path, report.chunk_count));
                    Ok(())
                }
                Err(err) => {
                    print_error(&format!("encrypt failed: {err}"));
                    Err(ExitCode::Generic)
                }
            }
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_decrypt.rs": r'''
        use std::path::PathBuf;

        use aurora_fs_container::{decrypt_path, DecryptOptions, UnlockMaterial};

        use crate::{exitcodes::ExitCode, output::{print_error, print_line}};

        pub fn run(input: PathBuf, output: Option<PathBuf>, key_file: PathBuf) -> Result<(), ExitCode> {
            let key_bytes = std::fs::read(&key_file).map_err(|err| {
                print_error(&format!("decrypt: failed to read key file: {err}"));
                ExitCode::IoFailure
            })?;
            let out = output.unwrap_or_else(|| input.with_extension("out"));
            match decrypt_path(&input, &out, UnlockMaterial::KeyFile(key_bytes), DecryptOptions::default()) {
                Ok(report) => {
                    print_line(&format!("decrypted: {} ({} chunks)", report.output_path, report.chunk_count));
                    Ok(())
                }
                Err(err) => {
                    print_error(&format!("decrypt failed: {err}"));
                    Err(ExitCode::WrongKeyOrAuthFailure)
                }
            }
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_rekey.rs": r'''
        use std::path::PathBuf;

        use crate::{exitcodes::ExitCode, output::print_error};

        pub fn run(_input: PathBuf, _output: Option<PathBuf>) -> Result<(), ExitCode> {
            print_error("rekey: not integrated yet");
            Err(ExitCode::Unsupported)
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_verify.rs": r'''
        use std::path::PathBuf;

        use crate::{exitcodes::ExitCode, output::print_error};

        pub fn run(_input: PathBuf) -> Result<(), ExitCode> {
            print_error("verify: not integrated yet");
            Err(ExitCode::Unsupported)
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_info.rs": r'''
        use std::path::PathBuf;

        use aurora_fs_container::inspect_path;

        use crate::{exitcodes::ExitCode, output::{print_error, print_line}};

        pub fn run(input: PathBuf) -> Result<(), ExitCode> {
            match inspect_path(&input) {
                Ok(report) => {
                    print_line(&format!("version: {}.{}", report.version_major, report.version_minor));
                    print_line(&format!("suite: 0x{:04x}", report.suite.as_u16()));
                    print_line(&format!("chunk_size: {}", report.chunk_size));
                    print_line(&format!("key_slots: {}", report.key_slot_count));
                    print_line(&format!("metadata_present: {}", report.metadata_present));
                    Ok(())
                }
                Err(err) => {
                    print_error(&format!("info failed: {err}"));
                    Err(ExitCode::MalformedInput)
                }
            }
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_keygen.rs": r'''
        use std::fs::OpenOptions;
        use std::io::Write;
        use std::path::PathBuf;

        use aurora_fs_crypto::{OsRandomSource, RandomSource};

        use crate::{exitcodes::ExitCode, output::{print_error, print_line}};

        #[cfg(unix)]
        use std::os::unix::fs::OpenOptionsExt;

        pub fn run(output: PathBuf, size: usize, overwrite: bool) -> Result<(), ExitCode> {
            if size < 32 {
                print_error("keygen: refusing key sizes below 32 bytes");
                return Err(ExitCode::UnsafePolicyRefusal);
            }
            let mut key = vec![0u8; size];
            let rng = OsRandomSource;
            if rng.fill(&mut key).is_err() {
                print_error("keygen: OS randomness failed");
                return Err(ExitCode::IoFailure);
            }
            let mut opts = OpenOptions::new();
            opts.write(true).create(true);
            if overwrite { opts.truncate(true); } else { opts.create_new(true); }
            #[cfg(unix)]
            { opts.mode(0o600); }
            let mut file = match opts.open(&output) {
                Ok(file) => file,
                Err(err) => {
                    print_error(&format!("keygen: failed to open output: {err}"));
                    return Err(ExitCode::IoFailure);
                }
            };
            if let Err(err) = file.write_all(&key) {
                print_error(&format!("keygen: failed to write key: {err}"));
                return Err(ExitCode::IoFailure);
            }
            print_line(&format!("key written: {} ({} bytes)", output.display(), size));
            Ok(())
        }
    ''',
    "crates/aurora-fs-cli/src/cmd_keyarmor.rs": r'''
        use std::fs::OpenOptions;
        use std::io::Write;
        use std::path::PathBuf;

        use base64::{engine::general_purpose::STANDARD, Engine};

        use crate::{cli::KeyArmorAction, exitcodes::ExitCode, output::{print_error, print_line}};

        #[cfg(unix)]
        use std::os::unix::fs::OpenOptionsExt;

        pub fn run(action: KeyArmorAction) -> Result<(), ExitCode> {
            match action {
                KeyArmorAction::Export { input, output, overwrite } => export_key(input, output, overwrite),
                KeyArmorAction::Import { input, output, overwrite } => import_key(input, output, overwrite),
            }
        }

        fn export_key(input: PathBuf, output: PathBuf, overwrite: bool) -> Result<(), ExitCode> {
            let bytes = std::fs::read(&input).map_err(|err| {
                print_error(&format!("keyarmor export: failed to read input: {err}"));
                ExitCode::IoFailure
            })?;
            let armored = STANDARD.encode(bytes);
            write_text(output, &armored, overwrite)?;
            print_line("warning: armored keys are easier to leak via copy, sync, screenshots, or chat");
            Ok(())
        }

        fn import_key(input: PathBuf, output: PathBuf, overwrite: bool) -> Result<(), ExitCode> {
            let text = std::fs::read_to_string(&input).map_err(|err| {
                print_error(&format!("keyarmor import: failed to read input: {err}"));
                ExitCode::IoFailure
            })?;
            let sanitized: String = text.chars().filter(|c| !c.is_whitespace()).collect();
            let bytes = STANDARD.decode(sanitized).map_err(|_| {
                print_error("keyarmor import: invalid armored key format");
                ExitCode::MalformedInput
            })?;
            write_binary(output, &bytes, overwrite)?;
            Ok(())
        }

        fn write_text(path: PathBuf, text: &str, overwrite: bool) -> Result<(), ExitCode> {
            let mut opts = OpenOptions::new();
            opts.write(true).create(true);
            if overwrite { opts.truncate(true); } else { opts.create_new(true); }
            #[cfg(unix)]
            { opts.mode(0o600); }
            let mut file = opts.open(&path).map_err(|err| {
                print_error(&format!("keyarmor: failed to open output: {err}"));
                ExitCode::IoFailure
            })?;
            file.write_all(text.as_bytes()).map_err(|err| {
                print_error(&format!("keyarmor: failed to write output: {err}"));
                ExitCode::IoFailure
            })?;
            print_line(&format!("armored key written: {}", path.display()));
            Ok(())
        }

        fn write_binary(path: PathBuf, bytes: &[u8], overwrite: bool) -> Result<(), ExitCode> {
            let mut opts = OpenOptions::new();
            opts.write(true).create(true);
            if overwrite { opts.truncate(true); } else { opts.create_new(true); }
            #[cfg(unix)]
            { opts.mode(0o600); }
            let mut file = opts.open(&path).map_err(|err| {
                print_error(&format!("keyarmor: failed to open output: {err}"));
                ExitCode::IoFailure
            })?;
            file.write_all(bytes).map_err(|err| {
                print_error(&format!("keyarmor: failed to write output: {err}"));
                ExitCode::IoFailure
            })?;
            print_line(&format!("binary key written: {}", path.display()));
            Ok(())
        }
    ''',
    "crates/aurora-fs-testvectors/Cargo.toml": r'''
        [package]
        name = "aurora-fs-testvectors"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true

        [lib]
        path = "src/lib.rs"
    ''',
    "crates/aurora-fs-testvectors/src/lib.rs": r'''
        pub const TODO_NOTE: &str = "Deterministic vectors will live here once full container vectors are frozen.";
    ''',
    "crates/aurora-fs-fuzz/Cargo.toml": r'''
        [package]
        name = "aurora-fs-fuzz"
        version.workspace = true
        edition.workspace = true
        license.workspace = true
        rust-version.workspace = true
        publish = false
    ''',
    "crates/aurora-fs-fuzz/fuzz_targets/README.md": r'''
        Placeholder fuzz target directory.
    ''',
}


def build_workspace(target: Path, force: bool) -> None:
    if target.exists() and any(target.iterdir()) and not force:
        raise SystemExit(
            f"Refusing to write into non-empty directory: {target}\n"
            "Pass --force to continue."
        )
    target.mkdir(parents=True, exist_ok=True)
    for rel_path, content in FILES.items():
        write_file(target, rel_path, content)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate the GitHub-ready AURORA-FS repository scaffold.")
    parser.add_argument("target", nargs="?", default="aurora-fs", help="Output directory")
    parser.add_argument("--force", action="store_true", help="Allow writing into a non-empty directory")
    args = parser.parse_args()

    root = Path(args.target).resolve()
    build_workspace(root, force=args.force)
    print(f"AURORA-FS repo scaffold written to: {root}")
    print("Next steps:")
    print("  1. cd", root)
    print("  2. cargo build --workspace")
    print("  3. cargo test --workspace")
    print("  4. git init && git add . && git commit -m 'Initial import'")
    print("  5. git remote add origin <your-github-repo-url>")
    print("  6. git push -u origin main")
    print("GitHub will then automatically offer Source code (zip) downloads.")
