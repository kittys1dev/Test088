use crate::params::Argon2Params;

pub fn validate_params(params: Argon2Params) -> Result<Argon2Params, &'static str> {
    if params.memory_kib < 64 * 1024 {
        return Err("memory_kib below implementation minimum");
    }
    if params.iterations == 0 {
        return Err("iterations must be non-zero");
    }
    if params.parallelism == 0 {
        return Err("parallelism must be non-zero");
    }
    if params.output_length < 32 {
        return Err("output_length must be at least 32 bytes");
    }
    Ok(params)
}
