use crate::{
    params::Argon2Params,
    presets::{memory_constrained_preset, portable_preset, strong_desktop_preset},
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CalibrationProfile {
    StrongDesktop,
    Portable,
    MemoryConstrained,
}

pub fn calibrate_for_host(profile: CalibrationProfile) -> Argon2Params {
    match profile {
        CalibrationProfile::StrongDesktop => strong_desktop_preset(),
        CalibrationProfile::Portable => portable_preset(),
        CalibrationProfile::MemoryConstrained => memory_constrained_preset(),
    }
}
