use crate::params::Argon2Params;

pub fn strong_desktop_preset() -> Argon2Params {
    Argon2Params {
        memory_kib: 2 * 1024 * 1024,
        iterations: 1,
        parallelism: 4,
        output_length: 32,
    }
}

pub fn portable_preset() -> Argon2Params {
    Argon2Params {
        memory_kib: 256 * 1024,
        iterations: 2,
        parallelism: 4,
        output_length: 32,
    }
}

pub fn memory_constrained_preset() -> Argon2Params {
    Argon2Params {
        memory_kib: 64 * 1024,
        iterations: 3,
        parallelism: 4,
        output_length: 32,
    }
}
