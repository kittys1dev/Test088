use std::fmt::{Display, Formatter};

use argon2::{Algorithm, Argon2, Params, Version};

use crate::{params::Argon2Params, policy::validate_params};

#[derive(Debug)]
pub enum KdfError {
    InvalidPolicy(&'static str),
    DerivationFailed,
}

impl Display for KdfError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidPolicy(msg) => write!(f, "invalid KDF policy: {msg}"),
            Self::DerivationFailed => write!(f, "Argon2id derivation failed"),
        }
    }
}

impl std::error::Error for KdfError {}

pub fn derive_slot_key(
    passphrase: &[u8],
    salt: &[u8],
    params: Argon2Params,
) -> Result<Vec<u8>, KdfError> {
    let params = validate_params(params).map_err(KdfError::InvalidPolicy)?;
    if salt.len() < 8 {
        return Err(KdfError::InvalidPolicy("salt must be at least 8 bytes"));
    }
    let argon_params = Params::new(
        params.memory_kib,
        params.iterations,
        params.parallelism,
        Some(params.output_length as usize),
    )
    .map_err(|_| KdfError::DerivationFailed)?;
    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, argon_params);
    let mut out = vec![0u8; params.output_length as usize];
    argon2
        .hash_password_into(passphrase, salt, &mut out)
        .map_err(|_| KdfError::DerivationFailed)?;
    Ok(out)
}
