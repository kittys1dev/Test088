pub const TODO_NOTE: &str =
    "Deterministic vectors will live here once full container vectors are frozen.";
