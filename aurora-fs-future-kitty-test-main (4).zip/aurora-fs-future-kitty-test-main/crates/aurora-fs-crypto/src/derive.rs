use tiny_keccak::{Hasher, IntoXof, Kmac, Xof};

use crate::aead::CryptoError;

pub trait DeriveEngine {
    fn derive(
        &self,
        customization: &[u8],
        input_key_material: &[u8],
        context: &[u8],
        out_len: usize,
    ) -> Result<Vec<u8>, CryptoError>;
}

#[derive(Debug, Default)]
pub struct Kmac256Derive;

impl DeriveEngine for Kmac256Derive {
    fn derive(
        &self,
        customization: &[u8],
        input_key_material: &[u8],
        context: &[u8],
        out_len: usize,
    ) -> Result<Vec<u8>, CryptoError> {
        if input_key_material.is_empty() {
            return Err(CryptoError::InvalidInput(
                "KMAC input key material must not be empty",
            ));
        }
        if out_len == 0 {
            return Err(CryptoError::InvalidInput(
                "derived output length must be non-zero",
            ));
        }
        let mut kmac = Kmac::v256(input_key_material, customization);
        kmac.update(context);
        let mut xof = kmac.into_xof();
        let mut out = vec![0u8; out_len];
        xof.squeeze(&mut out);
        Ok(out)
    }
}
