pub fn build_chunk_aad(header_binding: &[u8], chunk_index: u64, plaintext_length: u32) -> Vec<u8> {
    let mut out = Vec::with_capacity(header_binding.len() + 8 + 4);
    out.extend_from_slice(header_binding);
    out.extend_from_slice(&chunk_index.to_le_bytes());
    out.extend_from_slice(&plaintext_length.to_le_bytes());
    out
}
