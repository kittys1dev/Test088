use std::fmt::{Display, Formatter};

use aes_gcm_siv::{
    aead::{Aead, KeyInit, Payload},
    Aes256GcmSiv, Nonce,
};

#[derive(Debug)]
pub enum CryptoError {
    Unsupported(&'static str),
    InvalidInput(&'static str),
    RandomFailure(&'static str),
    AuthFailure(&'static str),
}

impl Display for CryptoError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Unsupported(what) => write!(f, "unsupported crypto operation: {what}"),
            Self::InvalidInput(what) => write!(f, "invalid crypto input: {what}"),
            Self::RandomFailure(what) => write!(f, "randomness failure: {what}"),
            Self::AuthFailure(what) => write!(f, "authentication failure: {what}"),
        }
    }
}

impl std::error::Error for CryptoError {}

pub trait AeadSuite {
    fn encrypt(
        &self,
        key: &[u8],
        nonce: &[u8],
        plaintext: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>, CryptoError>;
    fn decrypt(
        &self,
        key: &[u8],
        nonce: &[u8],
        ciphertext: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>, CryptoError>;
}

#[derive(Debug, Default)]
pub struct Aes256GcmSivBackend;

impl AeadSuite for Aes256GcmSivBackend {
    fn encrypt(
        &self,
        key: &[u8],
        nonce: &[u8],
        plaintext: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>, CryptoError> {
        if key.len() != 32 {
            return Err(CryptoError::InvalidInput(
                "AES-256-GCM-SIV requires a 32-byte key",
            ));
        }
        if nonce.len() != 12 {
            return Err(CryptoError::InvalidInput(
                "AES-256-GCM-SIV requires a 12-byte nonce",
            ));
        }
        let cipher = Aes256GcmSiv::new_from_slice(key)
            .map_err(|_| CryptoError::InvalidInput("failed to initialize AES-256-GCM-SIV"))?;
        let payload = Payload {
            msg: plaintext,
            aad,
        };
        cipher
            .encrypt(Nonce::from_slice(nonce), payload)
            .map_err(|_| CryptoError::AuthFailure("encrypt failed"))
    }

    fn decrypt(
        &self,
        key: &[u8],
        nonce: &[u8],
        ciphertext: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>, CryptoError> {
        if key.len() != 32 {
            return Err(CryptoError::InvalidInput(
                "AES-256-GCM-SIV requires a 32-byte key",
            ));
        }
        if nonce.len() != 12 {
            return Err(CryptoError::InvalidInput(
                "AES-256-GCM-SIV requires a 12-byte nonce",
            ));
        }
        let cipher = Aes256GcmSiv::new_from_slice(key)
            .map_err(|_| CryptoError::InvalidInput("failed to initialize AES-256-GCM-SIV"))?;
        let payload = Payload {
            msg: ciphertext,
            aad,
        };
        cipher
            .decrypt(Nonce::from_slice(nonce), payload)
            .map_err(|_| CryptoError::AuthFailure("decrypt failed"))
    }
}
