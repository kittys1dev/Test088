use aes_keywrap::Aes256KeyWrap;

use crate::aead::CryptoError;

pub trait WrapEngine {
    fn wrap_key(&self, wrapping_key: &[u8], content_key: &[u8]) -> Result<Vec<u8>, CryptoError>;
    fn unwrap_key(
        &self,
        wrapping_key: &[u8],
        wrapped_key: &[u8],
        expected_plaintext_len: usize,
    ) -> Result<Vec<u8>, CryptoError>;
}

#[derive(Debug, Default)]
pub struct Aes256KwpWrapEngine;

impl WrapEngine for Aes256KwpWrapEngine {
    fn wrap_key(&self, wrapping_key: &[u8], content_key: &[u8]) -> Result<Vec<u8>, CryptoError> {
        if wrapping_key.len() != 32 {
            return Err(CryptoError::InvalidInput(
                "AES-KWP requires a 32-byte wrapping key",
            ));
        }
        let mut kek = [0u8; 32];
        kek.copy_from_slice(wrapping_key);
        let kw = Aes256KeyWrap::new(&kek);
        kw.encapsulate(content_key)
            .map_err(|_| CryptoError::AuthFailure("key wrap failed"))
    }

    fn unwrap_key(
        &self,
        wrapping_key: &[u8],
        wrapped_key: &[u8],
        expected_plaintext_len: usize,
    ) -> Result<Vec<u8>, CryptoError> {
        if wrapping_key.len() != 32 {
            return Err(CryptoError::InvalidInput(
                "AES-KWP requires a 32-byte wrapping key",
            ));
        }
        let mut kek = [0u8; 32];
        kek.copy_from_slice(wrapping_key);
        let kw = Aes256KeyWrap::new(&kek);
        kw.decapsulate(wrapped_key, expected_plaintext_len)
            .map_err(|_| CryptoError::AuthFailure("key unwrap failed"))
    }
}
