use zeroize::Zeroize;

pub fn zeroize_bytes(bytes: &mut [u8]) {
    bytes.zeroize();
}
