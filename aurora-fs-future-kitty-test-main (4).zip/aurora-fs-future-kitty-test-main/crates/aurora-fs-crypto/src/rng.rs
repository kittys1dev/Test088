use crate::aead::CryptoError;

pub trait RandomSource {
    fn fill(&self, buf: &mut [u8]) -> Result<(), CryptoError>;
}

#[derive(Debug, Default)]
pub struct OsRandomSource;

impl RandomSource for OsRandomSource {
    fn fill(&self, buf: &mut [u8]) -> Result<(), CryptoError> {
        getrandom::fill(buf).map_err(|_| CryptoError::RandomFailure("OS RNG failed"))
    }
}
