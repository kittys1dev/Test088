use std::fmt::{Display, Formatter};
use std::path::Path;

use aurora_fs_core::{
    ChunkEntry, ChunkFlags, HeaderFlags, HeaderPrelude, KeySlotHeader, KeySlotRecord, ParseError,
    SuiteId, PRELUDE_LEN,
};
use aurora_fs_crypto::{
    build_chunk_aad, AeadSuite, Aes256GcmSivBackend, Aes256KwpWrapEngine, DeriveEngine,
    Kmac256Derive, OsRandomSource, RandomSource, WrapEngine,
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EncryptionMode {
    Standard,
    Hardened,
}

#[derive(Debug, Clone)]
pub struct EncryptOptions {
    pub suite: SuiteId,
    pub chunk_size: u32,
    pub mode: EncryptionMode,
}

impl Default for EncryptOptions {
    fn default() -> Self {
        Self {
            suite: SuiteId::Aes256GcmSiv,
            chunk_size: 4 * 1024 * 1024,
            mode: EncryptionMode::Standard,
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct DecryptOptions {
    pub overwrite: bool,
}

#[derive(Debug, Clone)]
pub enum UnlockMaterial {
    KeyFile(Vec<u8>),
    Passphrase(String),
    PassphraseAndKeyFile {
        passphrase: String,
        key_file: Vec<u8>,
    },
}

#[derive(Debug, Clone)]
pub struct EncryptReport {
    pub output_path: String,
    pub chunk_count: usize,
}

#[derive(Debug, Clone)]
pub struct DecryptReport {
    pub output_path: String,
    pub chunk_count: usize,
}

#[derive(Debug, Clone)]
pub struct InspectReport {
    pub version_major: u8,
    pub version_minor: u8,
    pub suite: SuiteId,
    pub chunk_size: u32,
    pub key_slot_count: u16,
    pub metadata_present: bool,
}

#[derive(Debug)]
pub enum ContainerError {
    Io(std::io::Error),
    Parse(ParseError),
    Crypto(&'static str),
    UnsupportedOperation(&'static str),
    InvalidState(&'static str),
}

impl Display for ContainerError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(e) => write!(f, "I/O error: {e}"),
            Self::Parse(e) => write!(f, "parse error: {e}"),
            Self::Crypto(msg) => write!(f, "crypto error: {msg}"),
            Self::UnsupportedOperation(msg) => write!(f, "unsupported operation: {msg}"),
            Self::InvalidState(msg) => write!(f, "invalid state: {msg}"),
        }
    }
}

impl std::error::Error for ContainerError {}

impl From<std::io::Error> for ContainerError {
    fn from(value: std::io::Error) -> Self {
        Self::Io(value)
    }
}

impl From<ParseError> for ContainerError {
    fn from(value: ParseError) -> Self {
        Self::Parse(value)
    }
}

fn derive_wrapping_key(keyfile: &[u8]) -> Result<Vec<u8>, ContainerError> {
    let derive = Kmac256Derive;
    derive
        .derive(b"aurora-slot-wrap-v1", keyfile, b"keyfile-wrap", 32)
        .map_err(|_| ContainerError::Crypto("failed to derive wrapping key"))
}

fn derive_header_binding(file_key: &[u8], public_header: &[u8]) -> Result<Vec<u8>, ContainerError> {
    let derive = Kmac256Derive;
    derive
        .derive(b"aurora-header-bind-v1", file_key, public_header, 32)
        .map_err(|_| ContainerError::Crypto("failed to derive header binding"))
}

fn derive_chunk_key_and_nonce(
    file_key: &[u8],
    header_binding: &[u8],
    chunk_index: u64,
) -> Result<(Vec<u8>, Vec<u8>), ContainerError> {
    let derive = Kmac256Derive;
    let mut context = Vec::with_capacity(header_binding.len() + 8);
    context.extend_from_slice(header_binding);
    context.extend_from_slice(&chunk_index.to_le_bytes());
    let key = derive
        .derive(b"aurora-chunk-key-v1", file_key, &context, 32)
        .map_err(|_| ContainerError::Crypto("failed to derive chunk key"))?;
    let nonce = derive
        .derive(b"aurora-chunk-nonce-v1", file_key, &context, 12)
        .map_err(|_| ContainerError::Crypto("failed to derive chunk nonce"))?;
    Ok((key, nonce))
}

fn parse_slots(bytes: &[u8], count: u16) -> Result<(Vec<KeySlotRecord>, usize), ContainerError> {
    let mut slots = Vec::with_capacity(count as usize);
    let mut cursor = 0usize;
    for _ in 0..count {
        let slot = KeySlotRecord::decode(&bytes[cursor..])?;
        let consumed = slot.encoded_len();
        cursor += consumed;
        slots.push(slot);
    }
    Ok((slots, cursor))
}

fn unlock_file_key(
    slots: &[KeySlotRecord],
    unlock: UnlockMaterial,
) -> Result<Vec<u8>, ContainerError> {
    match unlock {
        UnlockMaterial::KeyFile(keyfile) => {
            let wrapping_key = derive_wrapping_key(&keyfile)?;
            let wrap = Aes256KwpWrapEngine;
            let slot = slots
                .iter()
                .find(|slot| slot.header.slot_type == 0x02 && slot.header.kdf_id == 0xFF)
                .ok_or(ContainerError::UnsupportedOperation(
                    "no supported key-file slot found",
                ))?;
            wrap.unwrap_key(&wrapping_key, &slot.wrapped_key, 32)
                .map_err(|_| ContainerError::Crypto("key unwrap failed"))
        }
        UnlockMaterial::Passphrase(_) => Err(ContainerError::UnsupportedOperation(
            "passphrase unlock not integrated yet",
        )),
        UnlockMaterial::PassphraseAndKeyFile { .. } => Err(ContainerError::UnsupportedOperation(
            "hybrid unlock not integrated yet",
        )),
    }
}

pub fn encrypt_path(
    input: &Path,
    output: &Path,
    unlock: UnlockMaterial,
    opts: EncryptOptions,
) -> Result<EncryptReport, ContainerError> {
    if opts.mode != EncryptionMode::Standard {
        return Err(ContainerError::UnsupportedOperation(
            "hardened mode not integrated yet",
        ));
    }
    if opts.suite != SuiteId::Aes256GcmSiv {
        return Err(ContainerError::UnsupportedOperation(
            "only AES-256-GCM-SIV standard mode is integrated",
        ));
    }
    let keyfile = match unlock {
        UnlockMaterial::KeyFile(bytes) => bytes,
        UnlockMaterial::Passphrase(_) => {
            return Err(ContainerError::UnsupportedOperation(
                "passphrase unlock not integrated yet",
            ))
        }
        UnlockMaterial::PassphraseAndKeyFile { .. } => {
            return Err(ContainerError::UnsupportedOperation(
                "hybrid unlock not integrated yet",
            ))
        }
    };
    if opts.chunk_size == 0 {
        return Err(ContainerError::InvalidState("chunk size must be non-zero"));
    }

    let plaintext = std::fs::read(input)?;
    let rng = OsRandomSource;
    let mut file_key = vec![0u8; 32];
    rng.fill(&mut file_key)
        .map_err(|_| ContainerError::Crypto("failed to generate file key"))?;

    let wrapping_key = derive_wrapping_key(&keyfile)?;
    let wrap = Aes256KwpWrapEngine;
    let wrapped_key = wrap
        .wrap_key(&wrapping_key, &file_key)
        .map_err(|_| ContainerError::Crypto("failed to wrap file key"))?;

    let slot = KeySlotRecord {
        header: KeySlotHeader {
            slot_type: 0x02,
            kdf_id: 0xFF,
            slot_flags: 0,
            salt_length: 0,
            kdf_param_length: 0,
            wrapped_key_length: wrapped_key.len() as u16,
            key_check_length: 0,
            slot_extension_length: 0,
        },
        salt: Vec::new(),
        kdf_params: Vec::new(),
        wrapped_key,
        key_check: Vec::new(),
        slot_extensions: Vec::new(),
    };
    let slot_bytes = slot.encode();

    let chunk_count = if plaintext.is_empty() {
        1usize
    } else {
        plaintext.len().div_ceil(opts.chunk_size as usize)
    };

    let prelude = HeaderPrelude {
        chunk_size: opts.chunk_size,
        key_slot_count: 1,
        chunk_table_length: (chunk_count * ChunkEntry::ENCODED_LEN) as u64,
        ..HeaderPrelude::default()
    };
    let prelude_bytes = prelude.to_bytes();
    let mut public_header = Vec::with_capacity(prelude_bytes.len() + slot_bytes.len());
    public_header.extend_from_slice(&prelude_bytes);
    public_header.extend_from_slice(&slot_bytes);
    let header_binding = derive_header_binding(&file_key, &public_header)?;

    let aead = Aes256GcmSivBackend;
    let mut chunk_table = Vec::with_capacity(chunk_count);
    let mut ciphertext_stream = Vec::new();

    for chunk_index in 0..chunk_count {
        let start = chunk_index * opts.chunk_size as usize;
        let end = std::cmp::min(start + opts.chunk_size as usize, plaintext.len());
        let chunk_plaintext = if plaintext.is_empty() {
            &[][..]
        } else {
            &plaintext[start..end]
        };
        let (chunk_key, chunk_nonce) =
            derive_chunk_key_and_nonce(&file_key, &header_binding, chunk_index as u64)?;
        let aad = build_chunk_aad(
            &header_binding,
            chunk_index as u64,
            chunk_plaintext.len() as u32,
        );
        let ciphertext = aead
            .encrypt(&chunk_key, &chunk_nonce, chunk_plaintext, &aad)
            .map_err(|_| ContainerError::Crypto("chunk encryption failed"))?;
        let flags = if chunk_index + 1 == chunk_count {
            if chunk_plaintext.is_empty() {
                ChunkFlags(ChunkFlags::FINAL_CHUNK | ChunkFlags::ZERO_LENGTH_LOGICAL_CHUNK)
            } else {
                ChunkFlags(ChunkFlags::FINAL_CHUNK)
            }
        } else {
            ChunkFlags(0)
        };
        chunk_table.push(ChunkEntry {
            chunk_index: chunk_index as u64,
            plaintext_length: chunk_plaintext.len() as u32,
            ciphertext_length: ciphertext.len() as u32,
            ciphertext_offset: ciphertext_stream.len() as u64,
            flags,
            reserved: 0,
        });
        ciphertext_stream.extend_from_slice(&ciphertext);
    }

    let mut chunk_table_bytes = Vec::with_capacity(chunk_count * ChunkEntry::ENCODED_LEN);
    for entry in &chunk_table {
        chunk_table_bytes.extend_from_slice(&entry.encode());
    }

    let mut out = Vec::with_capacity(
        prelude_bytes.len() + slot_bytes.len() + chunk_table_bytes.len() + ciphertext_stream.len(),
    );
    out.extend_from_slice(&prelude_bytes);
    out.extend_from_slice(&slot_bytes);
    out.extend_from_slice(&chunk_table_bytes);
    out.extend_from_slice(&ciphertext_stream);
    std::fs::write(output, out)?;
    Ok(EncryptReport {
        output_path: output.display().to_string(),
        chunk_count,
    })
}

pub fn decrypt_path(
    input: &Path,
    output: &Path,
    unlock: UnlockMaterial,
    _opts: DecryptOptions,
) -> Result<DecryptReport, ContainerError> {
    let bytes = std::fs::read(input)?;
    let prelude = HeaderPrelude::from_bytes(&bytes)?;
    if prelude.suite_id != SuiteId::Aes256GcmSiv {
        return Err(ContainerError::UnsupportedOperation(
            "only AES-256-GCM-SIV standard mode is integrated",
        ));
    }
    let after_prelude = &bytes[PRELUDE_LEN..];
    let (slots, slot_bytes_len) = parse_slots(after_prelude, prelude.key_slot_count)?;
    let header_extensions_start = PRELUDE_LEN + slot_bytes_len;
    let header_extensions_end = header_extensions_start + prelude.header_extension_length as usize;
    let metadata_start = header_extensions_end;
    let metadata_end = metadata_start + prelude.encrypted_metadata_length as usize;
    let chunk_table_start = metadata_end;
    let chunk_table_end = chunk_table_start + prelude.chunk_table_length as usize;
    if chunk_table_end > bytes.len() {
        return Err(ContainerError::Parse(ParseError::Truncated(
            "chunk table region",
        )));
    }
    if prelude.chunk_table_length as usize % ChunkEntry::ENCODED_LEN != 0 {
        return Err(ContainerError::Parse(ParseError::Inconsistent(
            "chunk table length not aligned",
        )));
    }
    let ciphertext_stream_start = chunk_table_end;

    let public_header = &bytes[..header_extensions_end];
    let file_key = unlock_file_key(&slots, unlock)?;
    let header_binding = derive_header_binding(&file_key, public_header)?;

    let chunk_count = prelude.chunk_table_length as usize / ChunkEntry::ENCODED_LEN;
    let mut chunk_entries = Vec::with_capacity(chunk_count);
    for i in 0..chunk_count {
        let start = chunk_table_start + i * ChunkEntry::ENCODED_LEN;
        let end = start + ChunkEntry::ENCODED_LEN;
        chunk_entries.push(ChunkEntry::decode(&bytes[start..end])?);
    }

    let aead = Aes256GcmSivBackend;
    let mut plaintext = Vec::new();
    for entry in &chunk_entries {
        let ct_start = ciphertext_stream_start + entry.ciphertext_offset as usize;
        let ct_end = ct_start + entry.ciphertext_length as usize;
        if ct_end > bytes.len() {
            return Err(ContainerError::Parse(ParseError::Truncated(
                "ciphertext chunk",
            )));
        }
        let ciphertext = &bytes[ct_start..ct_end];
        let (chunk_key, chunk_nonce) =
            derive_chunk_key_and_nonce(&file_key, &header_binding, entry.chunk_index)?;
        let aad = build_chunk_aad(&header_binding, entry.chunk_index, entry.plaintext_length);
        let chunk_plaintext = aead
            .decrypt(&chunk_key, &chunk_nonce, ciphertext, &aad)
            .map_err(|_| ContainerError::Crypto("decryption failed"))?;
        if chunk_plaintext.len() != entry.plaintext_length as usize {
            return Err(ContainerError::Parse(ParseError::Inconsistent(
                "plaintext length mismatch",
            )));
        }
        plaintext.extend_from_slice(&chunk_plaintext);
    }

    std::fs::write(output, plaintext)?;
    Ok(DecryptReport {
        output_path: output.display().to_string(),
        chunk_count,
    })
}

pub fn inspect_path(input: &Path) -> Result<InspectReport, ContainerError> {
    let bytes = std::fs::read(input)?;
    let prelude = HeaderPrelude::from_bytes(&bytes)?;
    Ok(InspectReport {
        version_major: prelude.version.major,
        version_minor: prelude.version.minor,
        suite: prelude.suite_id,
        chunk_size: prelude.chunk_size,
        key_slot_count: prelude.key_slot_count,
        metadata_present: prelude.flags.contains(HeaderFlags::METADATA_PRESENT),
    })
}
