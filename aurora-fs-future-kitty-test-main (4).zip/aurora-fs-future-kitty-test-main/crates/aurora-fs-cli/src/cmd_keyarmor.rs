use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;

use base64::{engine::general_purpose::STANDARD, Engine};

use crate::{
    cli::KeyArmorAction,
    exitcodes::ExitCode,
    output::{print_error, print_line},
};

#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;

pub fn run(action: KeyArmorAction) -> Result<(), ExitCode> {
    match action {
        KeyArmorAction::Export {
            input,
            output,
            overwrite,
        } => export_key(input, output, overwrite),
        KeyArmorAction::Import {
            input,
            output,
            overwrite,
        } => import_key(input, output, overwrite),
    }
}

fn export_key(input: PathBuf, output: PathBuf, overwrite: bool) -> Result<(), ExitCode> {
    let bytes = std::fs::read(&input).map_err(|err| {
        print_error(&format!("keyarmor export: failed to read input: {err}"));
        ExitCode::IoFailure
    })?;
    let armored = STANDARD.encode(bytes);
    write_text(output, &armored, overwrite)?;
    print_line("warning: armored keys are easier to leak via copy, sync, screenshots, or chat");
    Ok(())
}

fn import_key(input: PathBuf, output: PathBuf, overwrite: bool) -> Result<(), ExitCode> {
    let text = std::fs::read_to_string(&input).map_err(|err| {
        print_error(&format!("keyarmor import: failed to read input: {err}"));
        ExitCode::IoFailure
    })?;
    let sanitized: String = text.chars().filter(|c| !c.is_whitespace()).collect();
    let bytes = STANDARD.decode(sanitized).map_err(|_| {
        print_error("keyarmor import: invalid armored key format");
        ExitCode::MalformedInput
    })?;
    write_binary(output, &bytes, overwrite)?;
    Ok(())
}

fn write_text(path: PathBuf, text: &str, overwrite: bool) -> Result<(), ExitCode> {
    let mut opts = OpenOptions::new();
    opts.write(true).create(true);
    if overwrite {
        opts.truncate(true);
    } else {
        opts.create_new(true);
    }
    #[cfg(unix)]
    {
        opts.mode(0o600);
    }
    let mut file = opts.open(&path).map_err(|err| {
        print_error(&format!("keyarmor: failed to open output: {err}"));
        ExitCode::IoFailure
    })?;
    file.write_all(text.as_bytes()).map_err(|err| {
        print_error(&format!("keyarmor: failed to write output: {err}"));
        ExitCode::IoFailure
    })?;
    print_line(&format!("armored key written: {}", path.display()));
    Ok(())
}

fn write_binary(path: PathBuf, bytes: &[u8], overwrite: bool) -> Result<(), ExitCode> {
    let mut opts = OpenOptions::new();
    opts.write(true).create(true);
    if overwrite {
        opts.truncate(true);
    } else {
        opts.create_new(true);
    }
    #[cfg(unix)]
    {
        opts.mode(0o600);
    }
    let mut file = opts.open(&path).map_err(|err| {
        print_error(&format!("keyarmor: failed to open output: {err}"));
        ExitCode::IoFailure
    })?;
    file.write_all(bytes).map_err(|err| {
        print_error(&format!("keyarmor: failed to write output: {err}"));
        ExitCode::IoFailure
    })?;
    print_line(&format!("binary key written: {}", path.display()));
    Ok(())
}
