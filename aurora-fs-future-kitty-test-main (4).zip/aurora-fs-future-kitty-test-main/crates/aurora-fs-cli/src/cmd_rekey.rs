use std::path::PathBuf;

use crate::{exitcodes::ExitCode, output::print_error};

pub fn run(_input: PathBuf, _output: Option<PathBuf>) -> Result<(), ExitCode> {
    print_error("rekey: not integrated yet");
    Err(ExitCode::Unsupported)
}
