use std::path::PathBuf;

use clap::{Parser, Subcommand};

use crate::exitcodes::ExitCode;

#[derive(Debug, Parser)]
#[command(name = "aurora", about = "AURORA-FS CLI")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Command,
}

#[derive(Debug, Subcommand)]
pub enum Command {
    Encrypt {
        input: PathBuf,
        #[arg(short, long)]
        output: Option<PathBuf>,
        #[arg(long)]
        key_file: PathBuf,
        #[arg(long, default_value_t = 4 * 1024 * 1024)]
        chunk_size: u32,
    },
    Decrypt {
        input: PathBuf,
        #[arg(short, long)]
        output: Option<PathBuf>,
        #[arg(long)]
        key_file: PathBuf,
    },
    Rekey {
        input: PathBuf,
        #[arg(short, long)]
        output: Option<PathBuf>,
    },
    Info {
        input: PathBuf,
    },
    Verify {
        input: PathBuf,
    },
    Keygen {
        #[arg(short, long)]
        output: PathBuf,
        #[arg(long, default_value_t = 32)]
        size: usize,
        #[arg(long)]
        overwrite: bool,
    },
    Keyarmor {
        #[command(subcommand)]
        action: KeyArmorAction,
    },
}

#[derive(Debug, Subcommand)]
pub enum KeyArmorAction {
    Export {
        input: PathBuf,
        #[arg(short, long)]
        output: PathBuf,
        #[arg(long)]
        overwrite: bool,
    },
    Import {
        input: PathBuf,
        #[arg(short, long)]
        output: PathBuf,
        #[arg(long)]
        overwrite: bool,
    },
}

pub fn dispatch(cli: Cli) -> Result<(), ExitCode> {
    match cli.command {
        Command::Encrypt {
            input,
            output,
            key_file,
            chunk_size,
        } => crate::cmd_encrypt::run(input, output, key_file, chunk_size),
        Command::Decrypt {
            input,
            output,
            key_file,
        } => crate::cmd_decrypt::run(input, output, key_file),
        Command::Rekey { input, output } => crate::cmd_rekey::run(input, output),
        Command::Info { input } => crate::cmd_info::run(input),
        Command::Verify { input } => crate::cmd_verify::run(input),
        Command::Keygen {
            output,
            size,
            overwrite,
        } => crate::cmd_keygen::run(output, size, overwrite),
        Command::Keyarmor { action } => crate::cmd_keyarmor::run(action),
    }
}
