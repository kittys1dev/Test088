use std::path::PathBuf;

use crate::{exitcodes::ExitCode, output::print_error};

pub fn run(_input: PathBuf) -> Result<(), ExitCode> {
    print_error("verify: not integrated yet");
    Err(ExitCode::Unsupported)
}
