use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;

use aurora_fs_crypto::{OsRandomSource, RandomSource};

use crate::{
    exitcodes::ExitCode,
    output::{print_error, print_line},
};

#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;

pub fn run(output: PathBuf, size: usize, overwrite: bool) -> Result<(), ExitCode> {
    if size < 32 {
        print_error("keygen: refusing key sizes below 32 bytes");
        return Err(ExitCode::UnsafePolicyRefusal);
    }
    let mut key = vec![0u8; size];
    let rng = OsRandomSource;
    if rng.fill(&mut key).is_err() {
        print_error("keygen: OS randomness failed");
        return Err(ExitCode::IoFailure);
    }
    let mut opts = OpenOptions::new();
    opts.write(true).create(true);
    if overwrite {
        opts.truncate(true);
    } else {
        opts.create_new(true);
    }
    #[cfg(unix)]
    {
        opts.mode(0o600);
    }
    let mut file = match opts.open(&output) {
        Ok(file) => file,
        Err(err) => {
            print_error(&format!("keygen: failed to open output: {err}"));
            return Err(ExitCode::IoFailure);
        }
    };
    if let Err(err) = file.write_all(&key) {
        print_error(&format!("keygen: failed to write key: {err}"));
        return Err(ExitCode::IoFailure);
    }
    print_line(&format!(
        "key written: {} ({} bytes)",
        output.display(),
        size
    ));
    Ok(())
}
