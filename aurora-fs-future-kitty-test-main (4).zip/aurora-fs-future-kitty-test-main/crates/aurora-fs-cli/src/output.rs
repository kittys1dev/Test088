pub fn print_line(message: &str) {
    println!("{message}");
}

pub fn print_error(message: &str) {
    eprintln!("{message}");
}
