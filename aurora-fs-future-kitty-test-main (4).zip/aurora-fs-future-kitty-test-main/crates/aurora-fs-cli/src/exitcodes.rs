#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExitCode {
    Success = 0,
    Generic = 1,
    MalformedInput = 2,
    WrongKeyOrAuthFailure = 3,
    Unsupported = 4,
    UnsafePolicyRefusal = 5,
    IoFailure = 6,
}
