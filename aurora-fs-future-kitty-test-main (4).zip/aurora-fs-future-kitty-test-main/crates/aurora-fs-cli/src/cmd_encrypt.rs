use std::path::PathBuf;

use aurora_fs_container::{encrypt_path, EncryptOptions, EncryptionMode, UnlockMaterial};
use aurora_fs_core::suite::SuiteId;

use crate::{
    exitcodes::ExitCode,
    output::{print_error, print_line},
};

pub fn run(
    input: PathBuf,
    output: Option<PathBuf>,
    key_file: PathBuf,
    chunk_size: u32,
) -> Result<(), ExitCode> {
    let key_bytes = std::fs::read(&key_file).map_err(|err| {
        print_error(&format!("encrypt: failed to read key file: {err}"));
        ExitCode::IoFailure
    })?;
    let out = output.unwrap_or_else(|| input.with_extension("aur"));
    let opts = EncryptOptions {
        suite: SuiteId::Aes256GcmSiv,
        chunk_size,
        mode: EncryptionMode::Standard,
    };
    match encrypt_path(&input, &out, UnlockMaterial::KeyFile(key_bytes), opts) {
        Ok(report) => {
            print_line(&format!(
                "encrypted: {} ({} chunks)",
                report.output_path, report.chunk_count
            ));
            Ok(())
        }
        Err(err) => {
            print_error(&format!("encrypt failed: {err}"));
            Err(ExitCode::Generic)
        }
    }
}
