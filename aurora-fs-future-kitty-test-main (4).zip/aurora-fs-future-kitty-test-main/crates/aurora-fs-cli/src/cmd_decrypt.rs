use std::path::PathBuf;

use aurora_fs_container::{decrypt_path, DecryptOptions, UnlockMaterial};

use crate::{
    exitcodes::ExitCode,
    output::{print_error, print_line},
};

pub fn run(input: PathBuf, output: Option<PathBuf>, key_file: PathBuf) -> Result<(), ExitCode> {
    let key_bytes = std::fs::read(&key_file).map_err(|err| {
        print_error(&format!("decrypt: failed to read key file: {err}"));
        ExitCode::IoFailure
    })?;
    let out = output.unwrap_or_else(|| input.with_extension("out"));
    match decrypt_path(
        &input,
        &out,
        UnlockMaterial::KeyFile(key_bytes),
        DecryptOptions::default(),
    ) {
        Ok(report) => {
            print_line(&format!(
                "decrypted: {} ({} chunks)",
                report.output_path, report.chunk_count
            ));
            Ok(())
        }
        Err(err) => {
            print_error(&format!("decrypt failed: {err}"));
            Err(ExitCode::WrongKeyOrAuthFailure)
        }
    }
}
