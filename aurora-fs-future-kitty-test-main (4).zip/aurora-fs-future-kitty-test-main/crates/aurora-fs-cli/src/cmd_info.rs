use std::path::PathBuf;

use aurora_fs_container::inspect_path;

use crate::{
    exitcodes::ExitCode,
    output::{print_error, print_line},
};

pub fn run(input: PathBuf) -> Result<(), ExitCode> {
    match inspect_path(&input) {
        Ok(report) => {
            print_line(&format!(
                "version: {}.{}",
                report.version_major, report.version_minor
            ));
            print_line(&format!("suite: 0x{:04x}", report.suite.as_u16()));
            print_line(&format!("chunk_size: {}", report.chunk_size));
            print_line(&format!("key_slots: {}", report.key_slot_count));
            print_line(&format!("metadata_present: {}", report.metadata_present));
            Ok(())
        }
        Err(err) => {
            print_error(&format!("info failed: {err}"));
            Err(ExitCode::MalformedInput)
        }
    }
}
