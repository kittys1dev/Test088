mod cli;
mod cmd_decrypt;
mod cmd_encrypt;
mod cmd_info;
mod cmd_keyarmor;
mod cmd_keygen;
mod cmd_rekey;
mod cmd_verify;
mod exitcodes;
mod output;

use clap::Parser;
use exitcodes::ExitCode;

fn main() {
    let cli = cli::Cli::parse();
    let code = match cli::dispatch(cli) {
        Ok(()) => ExitCode::Success,
        Err(code) => code,
    };
    std::process::exit(code as i32);
}
