#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FormatVersion {
    pub major: u8,
    pub minor: u8,
}

impl FormatVersion {
    pub const V1_0: Self = Self { major: 1, minor: 0 };
}

impl Default for FormatVersion {
    fn default() -> Self {
        Self::V1_0
    }
}
