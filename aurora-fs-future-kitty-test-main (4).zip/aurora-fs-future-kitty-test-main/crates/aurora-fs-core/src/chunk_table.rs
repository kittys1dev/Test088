use crate::{errors::ParseError, flags::ChunkFlags};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChunkEntry {
    pub chunk_index: u64,
    pub plaintext_length: u32,
    pub ciphertext_length: u32,
    pub ciphertext_offset: u64,
    pub flags: ChunkFlags,
    pub reserved: u32,
}

impl ChunkEntry {
    pub const ENCODED_LEN: usize = 32;

    pub fn encode(&self) -> [u8; Self::ENCODED_LEN] {
        let mut out = [0u8; Self::ENCODED_LEN];
        out[0..8].copy_from_slice(&self.chunk_index.to_le_bytes());
        out[8..12].copy_from_slice(&self.plaintext_length.to_le_bytes());
        out[12..16].copy_from_slice(&self.ciphertext_length.to_le_bytes());
        out[16..24].copy_from_slice(&self.ciphertext_offset.to_le_bytes());
        out[24..28].copy_from_slice(&self.flags.0.to_le_bytes());
        out[28..32].copy_from_slice(&self.reserved.to_le_bytes());
        out
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, ParseError> {
        if bytes.len() < Self::ENCODED_LEN {
            return Err(ParseError::InvalidLength {
                expected_at_least: Self::ENCODED_LEN,
                actual: bytes.len(),
            });
        }
        Ok(Self {
            chunk_index: u64::from_le_bytes(bytes[0..8].try_into().expect("len")),
            plaintext_length: u32::from_le_bytes(bytes[8..12].try_into().expect("len")),
            ciphertext_length: u32::from_le_bytes(bytes[12..16].try_into().expect("len")),
            ciphertext_offset: u64::from_le_bytes(bytes[16..24].try_into().expect("len")),
            flags: ChunkFlags(u32::from_le_bytes(bytes[24..28].try_into().expect("len"))),
            reserved: u32::from_le_bytes(bytes[28..32].try_into().expect("len")),
        })
    }
}
