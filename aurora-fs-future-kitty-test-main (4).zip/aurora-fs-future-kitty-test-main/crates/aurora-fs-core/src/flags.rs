#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct HeaderFlags(pub u32);

impl HeaderFlags {
    pub const METADATA_PRESENT: u32 = 1 << 0;
    pub const HARDENED_MODE: u32 = 1 << 1;
    pub const DETACHED_SIGNATURE_EXPECTED: u32 = 1 << 2;
    pub const ARMORED_EXPORT_COMPATIBLE: u32 = 1 << 3;
    pub const INTEGRITY_ONLY_ALLOWED: u32 = 1 << 4;

    pub fn contains(self, flag: u32) -> bool {
        self.0 & flag != 0
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct ChunkFlags(pub u32);

impl ChunkFlags {
    pub const FINAL_CHUNK: u32 = 1 << 0;
    pub const ZERO_LENGTH_LOGICAL_CHUNK: u32 = 1 << 1;
}
