#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u16)]
pub enum SuiteId {
    Aes256GcmSiv = 0x0001,
    AesSiv = 0x0002,
    HardenedGcmSivChaCha20Poly1305 = 0x1001,
    HardenedGcmSivAesSiv = 0x1002,
}

impl SuiteId {
    pub fn from_u16(value: u16) -> Option<Self> {
        match value {
            0x0001 => Some(Self::Aes256GcmSiv),
            0x0002 => Some(Self::AesSiv),
            0x1001 => Some(Self::HardenedGcmSivChaCha20Poly1305),
            0x1002 => Some(Self::HardenedGcmSivAesSiv),
            _ => None,
        }
    }

    pub fn as_u16(self) -> u16 {
        self as u16
    }
}
