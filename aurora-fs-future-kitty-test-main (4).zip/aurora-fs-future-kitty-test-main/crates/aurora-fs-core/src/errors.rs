use std::fmt::{Display, Formatter};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ParseError {
    InvalidLength {
        expected_at_least: usize,
        actual: usize,
    },
    InvalidMagic,
    UnsupportedSuite(u16),
    Truncated(&'static str),
    Inconsistent(&'static str),
}

impl Display for ParseError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidLength {
                expected_at_least,
                actual,
            } => {
                write!(
                    f,
                    "invalid length: expected at least {expected_at_least} bytes, got {actual}"
                )
            }
            Self::InvalidMagic => write!(f, "invalid magic bytes"),
            Self::UnsupportedSuite(id) => write!(f, "unsupported suite id: {id:#06x}"),
            Self::Truncated(what) => write!(f, "truncated field: {what}"),
            Self::Inconsistent(what) => write!(f, "inconsistent structure: {what}"),
        }
    }
}

impl std::error::Error for ParseError {}
