#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MetadataField {
    pub field_type: u8,
    pub flags: u8,
    pub value: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct MetadataMap {
    pub fields: Vec<MetadataField>,
}
