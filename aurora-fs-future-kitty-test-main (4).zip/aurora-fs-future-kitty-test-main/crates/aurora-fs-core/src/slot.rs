use crate::errors::ParseError;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeySlotHeader {
    pub slot_type: u8,
    pub kdf_id: u8,
    pub slot_flags: u16,
    pub salt_length: u16,
    pub kdf_param_length: u16,
    pub wrapped_key_length: u16,
    pub key_check_length: u16,
    pub slot_extension_length: u16,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeySlotRecord {
    pub header: KeySlotHeader,
    pub salt: Vec<u8>,
    pub kdf_params: Vec<u8>,
    pub wrapped_key: Vec<u8>,
    pub key_check: Vec<u8>,
    pub slot_extensions: Vec<u8>,
}

impl KeySlotRecord {
    pub fn encoded_len(&self) -> usize {
        14usize
            + self.header.salt_length as usize
            + self.header.kdf_param_length as usize
            + self.header.wrapped_key_length as usize
            + self.header.key_check_length as usize
            + self.header.slot_extension_length as usize
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(self.encoded_len());
        out.push(self.header.slot_type);
        out.push(self.header.kdf_id);
        out.extend_from_slice(&self.header.slot_flags.to_le_bytes());
        out.extend_from_slice(&self.header.salt_length.to_le_bytes());
        out.extend_from_slice(&self.header.kdf_param_length.to_le_bytes());
        out.extend_from_slice(&self.header.wrapped_key_length.to_le_bytes());
        out.extend_from_slice(&self.header.key_check_length.to_le_bytes());
        out.extend_from_slice(&self.header.slot_extension_length.to_le_bytes());
        out.extend_from_slice(&self.salt);
        out.extend_from_slice(&self.kdf_params);
        out.extend_from_slice(&self.wrapped_key);
        out.extend_from_slice(&self.key_check);
        out.extend_from_slice(&self.slot_extensions);
        out
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, ParseError> {
        if bytes.len() < 14 {
            return Err(ParseError::InvalidLength {
                expected_at_least: 14,
                actual: bytes.len(),
            });
        }
        let header = KeySlotHeader {
            slot_type: bytes[0],
            kdf_id: bytes[1],
            slot_flags: u16::from_le_bytes([bytes[2], bytes[3]]),
            salt_length: u16::from_le_bytes([bytes[4], bytes[5]]),
            kdf_param_length: u16::from_le_bytes([bytes[6], bytes[7]]),
            wrapped_key_length: u16::from_le_bytes([bytes[8], bytes[9]]),
            key_check_length: u16::from_le_bytes([bytes[10], bytes[11]]),
            slot_extension_length: u16::from_le_bytes([bytes[12], bytes[13]]),
        };
        let total = 14usize
            + header.salt_length as usize
            + header.kdf_param_length as usize
            + header.wrapped_key_length as usize
            + header.key_check_length as usize
            + header.slot_extension_length as usize;
        if bytes.len() < total {
            return Err(ParseError::InvalidLength {
                expected_at_least: total,
                actual: bytes.len(),
            });
        }
        let mut i = 14usize;
        let salt = bytes[i..i + header.salt_length as usize].to_vec();
        i += header.salt_length as usize;
        let kdf_params = bytes[i..i + header.kdf_param_length as usize].to_vec();
        i += header.kdf_param_length as usize;
        let wrapped_key = bytes[i..i + header.wrapped_key_length as usize].to_vec();
        i += header.wrapped_key_length as usize;
        let key_check = bytes[i..i + header.key_check_length as usize].to_vec();
        i += header.key_check_length as usize;
        let slot_extensions = bytes[i..i + header.slot_extension_length as usize].to_vec();
        Ok(Self {
            header,
            salt,
            kdf_params,
            wrapped_key,
            key_check,
            slot_extensions,
        })
    }
}
