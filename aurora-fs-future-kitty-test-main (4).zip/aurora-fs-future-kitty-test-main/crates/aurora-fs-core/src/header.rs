use crate::{errors::ParseError, flags::HeaderFlags, suite::SuiteId, version::FormatVersion};

pub const MAGIC: &[u8; 8] = b"AURFS256";
pub const PRELUDE_LEN: usize = 58;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HeaderPrelude {
    pub version: FormatVersion,
    pub suite_id: SuiteId,
    pub flags: HeaderFlags,
    pub chunk_size: u32,
    pub key_slot_count: u16,
    pub header_extension_length: u32,
    pub encrypted_metadata_length: u64,
    pub chunk_table_length: u64,
    pub reserved: [u8; 16],
}

impl Default for HeaderPrelude {
    fn default() -> Self {
        Self {
            version: FormatVersion::default(),
            suite_id: SuiteId::Aes256GcmSiv,
            flags: HeaderFlags(0),
            chunk_size: 4 * 1024 * 1024,
            key_slot_count: 1,
            header_extension_length: 0,
            encrypted_metadata_length: 0,
            chunk_table_length: 0,
            reserved: [0u8; 16],
        }
    }
}

impl HeaderPrelude {
    pub fn to_bytes(&self) -> [u8; PRELUDE_LEN] {
        let mut out = [0u8; PRELUDE_LEN];
        let mut i = 0usize;
        out[i..i + 8].copy_from_slice(MAGIC);
        i += 8;
        out[i] = self.version.major;
        i += 1;
        out[i] = self.version.minor;
        i += 1;
        out[i..i + 2].copy_from_slice(&self.suite_id.as_u16().to_le_bytes());
        i += 2;
        out[i..i + 4].copy_from_slice(&self.flags.0.to_le_bytes());
        i += 4;
        out[i..i + 4].copy_from_slice(&self.chunk_size.to_le_bytes());
        i += 4;
        out[i..i + 2].copy_from_slice(&self.key_slot_count.to_le_bytes());
        i += 2;
        out[i..i + 4].copy_from_slice(&self.header_extension_length.to_le_bytes());
        i += 4;
        out[i..i + 8].copy_from_slice(&self.encrypted_metadata_length.to_le_bytes());
        i += 8;
        out[i..i + 8].copy_from_slice(&self.chunk_table_length.to_le_bytes());
        i += 8;
        out[i..i + 16].copy_from_slice(&self.reserved);
        out
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self, ParseError> {
        if bytes.len() < PRELUDE_LEN {
            return Err(ParseError::InvalidLength {
                expected_at_least: PRELUDE_LEN,
                actual: bytes.len(),
            });
        }
        if &bytes[0..8] != MAGIC {
            return Err(ParseError::InvalidMagic);
        }
        let version = FormatVersion {
            major: bytes[8],
            minor: bytes[9],
        };
        let suite = u16::from_le_bytes([bytes[10], bytes[11]]);
        let suite_id = SuiteId::from_u16(suite).ok_or(ParseError::UnsupportedSuite(suite))?;
        let flags = HeaderFlags(u32::from_le_bytes(bytes[12..16].try_into().expect("len")));
        let chunk_size = u32::from_le_bytes(bytes[16..20].try_into().expect("len"));
        let key_slot_count = u16::from_le_bytes(bytes[20..22].try_into().expect("len"));
        let header_extension_length = u32::from_le_bytes(bytes[22..26].try_into().expect("len"));
        let encrypted_metadata_length = u64::from_le_bytes(bytes[26..34].try_into().expect("len"));
        let chunk_table_length = u64::from_le_bytes(bytes[34..42].try_into().expect("len"));
        let reserved: [u8; 16] = bytes[42..58].try_into().expect("len");
        Ok(Self {
            version,
            suite_id,
            flags,
            chunk_size,
            key_slot_count,
            header_extension_length,
            encrypted_metadata_length,
            chunk_table_length,
            reserved,
        })
    }
}
