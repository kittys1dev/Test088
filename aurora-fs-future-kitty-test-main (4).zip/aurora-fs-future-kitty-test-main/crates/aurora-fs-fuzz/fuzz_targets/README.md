Placeholder fuzz target directory.
