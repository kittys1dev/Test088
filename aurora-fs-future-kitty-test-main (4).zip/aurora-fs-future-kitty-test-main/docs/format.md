# AURORA-FS Container Notes

Current generated container layout:

- 58-byte fixed prelude
- one key slot record
- no header extensions
- no encrypted metadata block yet
- fixed-size chunk table
- ciphertext stream

Current implementation supports key-file-only standard mode.
