# Release Notes

## GitHub ZIP download

After pushing this repository to GitHub, GitHub automatically provides a downloadable ZIP from the repository page.

## Release artifacts

Intended release flow:
- push repository
- tag a version like `v0.1.0`
- let GitHub Actions build artifacts
- optionally use cargo-dist for install scripts and archives

## Local release smoke test

```bash
cargo build --workspace
cargo test --workspace
cargo install cargo-dist --locked
cargo dist build
```
