# CLI Notes

Working commands:
- info
- keygen
- keyarmor export
- keyarmor import
- encrypt --key-file
- decrypt --key-file

Stubbed fail-closed commands:
- rekey
- verify
