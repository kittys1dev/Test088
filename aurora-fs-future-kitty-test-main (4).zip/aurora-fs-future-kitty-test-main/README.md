# AURORA-FS

AURORA-FS is a local-first, offline-capable, no-backdoor file-encryption project.

## Current status

This is a **pre-alpha** repository scaffold with a narrow working path:

- `aurora info`
- `aurora keygen`
- `aurora keyarmor export`
- `aurora keyarmor import`
- `aurora encrypt --key-file ...`
- `aurora decrypt --key-file ...`

Current end-to-end support is intentionally narrow:

- standard mode only
- key-file unlock only
- no detached signatures
- no passphrase or hybrid unlock yet
- no encrypted metadata block yet
- no rekey yet

## Build

```bash
cargo build --workspace
cargo test --workspace
cargo run -p aurora-fs-cli -- keygen -o mykey.bin
cargo run -p aurora-fs-cli -- encrypt secrets.txt --key-file mykey.bin
cargo run -p aurora-fs-cli -- decrypt secrets.aur --key-file mykey.bin
```

## Security note

Do not market this as a finished security product yet.
Ship nothing public as production-safe until external review, deterministic vectors, tamper tests, and wrong-key failure behavior are complete.
