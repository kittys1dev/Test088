# Security Policy

AURORA-FS is pre-alpha.
Unsupported or incomplete cryptographic operations must fail closed.

Do not open public issues for unreleased crypto-path vulnerabilities.
Establish a private security contact before public alpha.
