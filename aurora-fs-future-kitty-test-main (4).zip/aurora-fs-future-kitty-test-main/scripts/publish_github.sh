#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${1:-}"
if [[ -z "$REPO_URL" ]]; then
  echo "usage: scripts/publish_github.sh <git@github.com:USER/REPO.git|https://github.com/USER/REPO.git>"
  exit 1
fi

git init
git add .
git commit -m "Initial AURORA-FS import"
git branch -M main
git remote add origin "$REPO_URL"
git push -u origin main

echo
echo "After push, GitHub will automatically offer Source code (zip)."
echo "Optional next step: create a tag like v0.1.0 and push it."
